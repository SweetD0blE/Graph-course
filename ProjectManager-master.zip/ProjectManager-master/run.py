import socket
from app.logging import logger
from pathlib import Path
from app.utils import send_internal_mail, get_gp_connection
from apscheduler.schedulers.background import BackgroundScheduler

from app import create_app
app = create_app()

def write_app_link(port=443, file_path='link.txt'):
    hostname = socket.gethostname()
    local_ip = socket.gethostbyname(hostname)

    link = f'http://{local_ip}:{port}'

    Path(file_path).write_text(link)
    logger.info(f'Ссылка сохранена: {link}')

if __name__ == '__main__':
    port = 443
    write_app_link(port)

    try:
        get_gp_connection()
    except Exception as e:
        logger.error(f'Ошибка выгрузки сотрудников с БД: {e}')

    app.run(host='0.0.0.0', port=port)
