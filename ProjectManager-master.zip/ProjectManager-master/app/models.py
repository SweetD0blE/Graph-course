import threading
from datetime import datetime
from flask_login import UserMixin
from app.extensions import db

class Project(db.Model):
    """
    Модель проекта (основной объект системы).
    Хранит всю информацию, необходимую для управления, фильтрации и экспорта проектов.
    """
    id = db.Column(db.Integer, primary_key=True)
    project_number = db.Column(db.String(10), unique=True, nullable=False)

    rating_id = db.Column(db.Integer)  # ID проекта в рейтинге ТБ
    km_sup = db.Column(db.String(11))  # ID проекта в СУП
    sprint_id = db.Column(db.Integer)  # ID спринта
    title = db.Column(db.String(200), nullable=False)

    project_type = db.Column(db.String(10), nullable=False)
    curator = db.Column(db.String(32), nullable=False)  # Табельный номер
    product_owner = db.Column(db.String(32), nullable=False)  # Табельный номер
    team = db.Column(db.String(500), nullable=False)  # Список табельных через ;

    deadline = db.Column(db.Date, nullable=False)
    tech_extensions = db.Column(db.Integer, default=0)

    agile_open_date = db.Column(db.Date, nullable=False)
    open_protocol = db.Column(db.Integer, nullable=False)
    agile_close_date = db.Column(db.Date)
    close_protocol = db.Column(db.Integer)

    base_bank = db.Column(db.String(5), nullable=False)

    # Чекбоксы банков-участников
    bb = db.Column(db.Boolean, default=False)
    vvb = db.Column(db.Boolean, default=False)
    dvb = db.Column(db.Boolean, default=False)
    mb = db.Column(db.Boolean, default=False)
    pb = db.Column(db.Boolean, default=False)
    szb = db.Column(db.Boolean, default=False)
    sibb = db.Column(db.Boolean, default=False)
    srb = db.Column(db.Boolean, default=False)
    ub = db.Column(db.Boolean, default=False)
    ccb = db.Column(db.Boolean, default=False)
    yuzb = db.Column(db.Boolean, default=False)

    backlog_date = db.Column(db.Date)

    creator = db.Column(db.Integer, nullable=False)  # ID пользователя, создавшего проект
    deadline_notified = db.Column(db.Boolean, default=False)  # Уведомление о дедлайне отправлено
    close_notified = db.Column(db.Boolean, default=False)  # Уведомление о закрытии отправлено

    status = db.Column(db.String(25), nullable=False, default='В работе')  # Статус проекта
    create_at = db.Column(db.DateTime, default=datetime.utcnow)

    @staticmethod
    def generate_project_number():
        """
        Генерация уникального номера проекта формата: <год>_<порядковый номер>
        Например: 2025_01
        """
        current_year = datetime.now().year
        prefix = f'{current_year}'

        last_project = Project.query.filter(Project.project_number.startswith(prefix)).all()

        max_number = 1
        for project in last_project:
            try:
                number_part = int(project.project_number.split('_')[1])
                if number_part > max_number:
                    max_number = number_part
            except ValueError:
                max_number = 1

        new_number = max_number + 1
        return f'{current_year}_{str(new_number).zfill(2)}'

    def to_dict(self):
        """
        Преобразует объект проекта в словарь, используемый для экспорта (например, в Excel).
        """
        return {
            'N п/п': self.id,
            'Номер проекта': self.project_number,
            'ID проекта в рейтинге ТБ': self.rating_id,
            'КМ в СУП': self.km_sup,
            'ID Спринта в реестре спринтов BL СВА': self.sprint_id,
            'Название проекта': self.title,
            'Тип проекта': self.project_type,
            'Куратор': self.curator,
            'P.Owner (спикер)': self.product_owner,
            'Команда': self.team.rstrip(';'),
            'Deadline': self.deadline,
            'Количество технических продлений': self.tech_extensions,
            'Дата открытия на Agile BL': self.agile_open_date,
            'Номер протокола (открытие)': self.open_protocol,
            'Дата закрытия на Agile BL': self.agile_close_date,
            'Номер протокола (закрытие)': self.close_protocol,
            'Предполагаемая дата выхода на Backlog СВА' : self.backlog_date,
            'Базовый Банк': self.base_bank,
            'ББ': self.bb,
            'ВВБ': self.vvb,
            'ДВБ': self.dvb,
            'МБ': self.mb,
            'ПБ': self.pb,
            'СЗБ': self.szb,
            'СибБ': self.sibb,
            'СРБ': self.srb,
            'УБ': self.ub,
            'ЦЧБ': self.ccb,
            'ЮЗБ': self.yuzb,
            'Ведущий проекта': self.creator,
            'Статус проекта': self.status,
            'Дата создания': self.create_at,
            'Оповещение о дедлайне': self.deadline_notified,
            'Оповещение о закрытии': self.close_notified
        }

    def to_dict_expt(self):
        """
        Преобразует объект проекта в словарь, используемый для экспорта (например, в Excel).
        """
        return {
            'N п/п': self.id,
            'Номер проекта': self.project_number,
            'ID проекта в рейтинге ТБ': self.rating_id,
            'КМ в СУП': self.km_sup,
            'ID Спринта в реестре спринтов BL СВА': self.sprint_id,
            'Название проекта': self.title,
            'Тип проекта': self.project_type,
            'Куратор': self.curator,
            'P.Owner (спикер)': self.product_owner,
            'Команда': self.team.rstrip(';'),
            'Deadline': self.deadline,
            'Количество технических продлений': self.tech_extensions,
            'Дата открытия на Agile BL': self.agile_open_date,
            'Номер протокола (открытие)': self.open_protocol,
            'Дата закрытия на Agile BL': self.agile_close_date,
            'Номер протокола (закрытие)': self.close_protocol,
            'Предполагаемая дата выхода на Backlog СВА' : self.backlog_date,
            'Базовый Банк': self.base_bank,
            'ББ': 1 if self.bb else '',
            'ВВБ': 1 if self.vvb else '',
            'ДВБ': 1 if self.dvb else '',
            'МБ': 1 if self.mb else '',
            'ПБ': 1 if self.pb else '',
            'СЗБ': 1 if self.szb else '',
            'СибБ': 1 if self.sibb else '',
            'СРБ': 1 if self.srb else '',
            'УБ': 1 if self.ub else '',
            'ЦЧБ': 1 if self.ccb else '',
            'ЮЗБ': 1 if self.yuzb else ''
        }

class Employee(db.Model):
    """
    Таблица сотрудников, используется как источник данных при регистрации пользователей.
    """
    id = db.Column(db.Integer, primary_key=True)
    full_name = db.Column(db.String(100))
    staff_number = db.Column(db.String(8), unique=True, nullable=False)
    position = db.Column(db.String(150))
    department = db.Column(db.String(150))
    email = db.Column(db.String(100), unique=True)

class Users(db.Model, UserMixin):
    """
    Таблица пользователей системы (зарегистрированных через форму).
    Атрибут `status`: 0 - обычный пользователь, 1 - администратор.
    """
    id = db.Column(db.Integer, primary_key=True)
    full_name = db.Column(db.String(100))
    staff_number = db.Column(db.String(8), unique=True, nullable=False)
    position = db.Column(db.String(150))
    department = db.Column(db.String(150))
    email = db.Column(db.String(100), unique=True)

    status = db.Column(db.Integer, nullable=False, default=0)  # 0 - user, 1 - admin
    verification_code = db.Column(db.String(6))  # код подтверждения email
    is_verified = db.Column(db.Boolean, default=False)  # подтвержден ли пользователь

    def to_dict(self):
        return {
            'Пользовательский айди': self.id,
            'Табельный номер': self.staff_number,
            'ФИО': self.full_name,
            'Отдел': self.department,
            'Должность': self.position,
            'Почта': self.email
        }

    def populate_from_employee(self, employee):
        """
        Заполняет поля пользователя на основе сотрудника из таблицы Employee.
        """
        self.id = employee.id
        self.full_name = employee.full_name
        self.staff_number = employee.staff_number
        self.position = employee.position
        self.department = employee.department

    def get_id(self):
        """Метод для flask-login, возвращает ID как строку."""
        return str(self.id)


def run_import_in_thread(app):
    """
    Фоновая задача для импорта сотрудников из SVA.
    Вызывается при запуске приложения.
    """
    with app.app_context():
        try:
            from app.utils import load_sva_persons
            load_sva_persons(db)
        except Exception as e:
            print(f'[Импорт сотрудников] Ошибка: {e}')


def register_background_tasks(app):
    """
    Регистрирует фоновую задачу в отдельном потоке.
    """
    thread = threading.Thread(target=run_import_in_thread, args=(app,))
    thread.start()
