from __future__ import annotations

import csv
import io
import re
from collections import Counter
from datetime import date, datetime, time, timedelta

from flask import Blueprint, Response, render_template, request, url_for
from flask_login import login_required
from openpyxl import Workbook
from openpyxl.chart import BarChart, DoughnutChart, LineChart, Reference
from openpyxl.styles import Alignment, Border, Font, PatternFill, Side
from openpyxl.utils import get_column_letter

from app.config import Settings, YAML_FILE, load_yaml_config, yaml_config
from app.models import Employee, Project, Users
from app.routes.project_routes import (
    FILTER_BASE_BANKS,
    FILTER_PROJECT_STATUSES,
    FILTER_PROJECT_TYPES,
)

analytics_bp = Blueprint("analytics", __name__, url_prefix="/analytics")

WORK_STATUS = "В работе"
FINISHED_STATUS = "Завершен"
TECH_EXTENSION_STATUS = "Техническое продление"
OVERDUE_STATUS = "Задерживается"
WAITING_RATING_STATUS = "Ожидает ID в рейтинге ТБ"
WAITING_BACKLOG_STATUS = "Ожидает выхода на Backlog СВА"

BANK_FIELD_LABELS = {
    "bb": "ББ",
    "vvb": "ВВБ",
    "dvb": "ДВБ",
    "mb": "МБ",
    "pb": "ПБ",
    "szb": "СЗБ",
    "sibb": "СибБ",
    "srb": "СРБ",
    "ub": "УБ",
    "ccb": "ЦЧБ",
    "yuzb": "ЮЗБ",
}

# Основной пул направлений кураторов для отдельного фильтра графика
# "Agile BL → BL СВА по аудиторским кварталам".
#
# Важно:
# - табельные номера храним строками, чтобы не потерять ведущие нули;
# - в каждом направлении можно спокойно добавить еще 3-4 куратора;
# - если в проекте указано несколько кураторов, проект попадет в направление,
#   когда совпал хотя бы один из них.
CURATOR_DIRECTIONS = {
    "compliance": {
        "label": "Compliance",
        "staff_numbers": {
            "02818384",
            # "00000000",  # добавить куратора Compliance
            # "00000000",  # добавить куратора Compliance
            # "00000000",  # добавить куратора Compliance
        },
    },
    "project_office": {
        "label": "Проектный офис",
        "staff_numbers": {
            "29483814",
            # "00000000",  # добавить куратора Проектного офиса
            # "00000000",  # добавить куратора Проектного офиса
            # "00000000",  # добавить куратора Проектного офиса
        },
    },
    "operations": {
        "label": "Operations",
        "staff_numbers": {
            "4882828",
            # "00000000",  # добавить куратора Operations
            # "00000000",  # добавить куратора Operations
            # "00000000",  # добавить куратора Operations
        },
    },
}

CHART_COLORS = [
    "#2563eb",
    "#16a34a",
    "#f59e0b",
    "#7c3aed",
    "#64748b",
    "#0ea5e9",
    "#ef4444",
    "#14b8a6",
]

STATUS_SHORT_LABELS = {
    WORK_STATUS: "В работе",
    FINISHED_STATUS: "Завершено",
    TECH_EXTENSION_STATUS: "Тех. продление",
    OVERDUE_STATUS: "Задерживается",
    WAITING_RATING_STATUS: "Ожид. ID ТБ",
    WAITING_BACKLOG_STATUS: "Ожид. Backlog",
}

STATUS_BADGE_CLASSES = {
    WORK_STATUS: "status-work",
    FINISHED_STATUS: "status-done",
    TECH_EXTENSION_STATUS: "status-tech",
    OVERDUE_STATUS: "status-overdue",
    WAITING_RATING_STATUS: "status-rating",
    WAITING_BACKLOG_STATUS: "status-backlog",
}

RU_MONTHS = [
    "янв",
    "фев",
    "мар",
    "апр",
    "май",
    "июн",
    "июл",
    "авг",
    "сен",
    "окт",
    "ноя",
    "дек",
]


def is_filled(value) -> bool:
    """Проверяет, что поле реально заполнено. Работает для int, str, None."""
    return value is not None and str(value).strip() != ""


def parse_config_date(value) -> date | None:
    if not value:
        return None
    if isinstance(value, datetime):
        return value.date()
    if isinstance(value, date):
        return value
    try:
        return datetime.strptime(str(value).strip(), "%Y-%m-%d").date()
    except ValueError:
        return None


def get_analytics_config() -> dict:
    """
    Берём настройки аналитики максимально устойчиво.

    Почему не только yaml_config:
    - в app/config.py блок Settings.ANALYTICS мог быть добавлен позже;
    - Flask мог быть запущен до изменения config.yaml;
    - при отладке полезно иметь fallback на свежее чтение config.yaml.
    """
    settings_config = getattr(Settings, "ANALYTICS", None)
    if isinstance(settings_config, dict) and settings_config:
        return settings_config

    module_config = yaml_config.get("analytics", {}) if isinstance(yaml_config, dict) else {}
    if isinstance(module_config, dict) and module_config:
        return module_config

    try:
        fresh_yaml_config = load_yaml_config(YAML_FILE)
    except Exception:
        return {}

    fresh_config = fresh_yaml_config.get("analytics", {}) if isinstance(fresh_yaml_config, dict) else {}
    return fresh_config if isinstance(fresh_config, dict) else {}


def get_audit_quarters() -> list[dict]:
    """
    Возвращает аудиторские кварталы из config.yaml.

    Ожидаемый формат:
    analytics:
      audit_quarters:
        - code: winter_2026
          label: "Зима 2026"
          year: 2026
          start: "2025-11-12"
          end: "2026-02-19"
    """
    analytics_config = get_analytics_config()
    raw_quarters = analytics_config.get("audit_quarters", []) or []
    quarters = []

    for index, item in enumerate(raw_quarters):
        if not isinstance(item, dict):
            continue

        label = str(item.get("label") or item.get("name") or "").strip()
        start = parse_config_date(item.get("start"))
        end = parse_config_date(item.get("end"))

        if not label or not start or not end:
            continue

        if start > end:
            start, end = end, start

        code = str(item.get("code") or "").strip()
        if not code:
            code = f"audit_quarter_{index + 1}"

        year_value = item.get("year")
        if not year_value:
            year_match = re.search(r"(20\d{2})", label)
            year_value = year_match.group(1) if year_match else str(end.year)

        quarters.append(
            {
                "code": code,
                "label": label,
                "start": start,
                "end": end,
                "year": str(year_value),
                "period": f"{start.strftime('%d.%m.%Y')} — {end.strftime('%d.%m.%Y')}",
            }
        )

    return sorted(quarters, key=lambda item: (item["start"], item["end"]))


def get_audit_years(audit_quarters: list[dict]) -> list[str]:
    return sorted({str(item["year"]) for item in audit_quarters if item.get("year")})


def get_selected_audit_quarter(code: str | None, audit_quarters: list[dict]) -> dict | None:
    code = (code or "").strip()
    if not code:
        return None
    return next((item for item in audit_quarters if item["code"] == code), None)


def get_audit_year_period(year: str | None, audit_quarters: list[dict]) -> tuple[date | None, date | None]:
    year = (year or "").strip()
    if not year:
        return None, None

    year_quarters = [item for item in audit_quarters if item.get("year") == year]
    if not year_quarters:
        return None, None

    return min(item["start"] for item in year_quarters), max(item["end"] for item in year_quarters)


def date_in_period(value: date | datetime | None, start: date, end: date) -> bool:
    if not value:
        return False
    if isinstance(value, datetime):
        value = value.date()
    return start <= value <= end


def is_internal_agile_closed(project: Project) -> bool:
    """
    Проект считается закрытым на внутреннем Agile Backlog, если есть дата закрытия,
    есть ID проекта в рейтинге ТБ и статус финальный либо ожидание выхода на BL СВА.
    Второй статус учитываем как внутренне закрытый проект, который ожидает внешнего Backlog.
    """
    return (
        project.status in {FINISHED_STATUS, WAITING_BACKLOG_STATUS}
        and is_filled(project.rating_id)
        and project.agile_close_date is not None
    )


def is_released_to_sva_backlog(project: Project) -> bool:
    return is_internal_agile_closed(project) and is_filled(project.sprint_id)


def is_planned_to_sva_backlog(project: Project) -> bool:
    return (
        is_internal_agile_closed(project)
        and not is_filled(project.sprint_id)
        and project.status == WAITING_BACKLOG_STATUS
    )


def parse_date_param(param_name: str) -> date | None:
    value = request.args.get(param_name, "").strip()
    if not value:
        return None
    try:
        return datetime.strptime(value, "%Y-%m-%d").date()
    except ValueError:
        return None


def build_analytics_query():
    audit_quarters = get_audit_quarters()
    selected_filters = {
        "open_date_from": request.args.get("open_date_from", "").strip(),
        "open_date_to": request.args.get("open_date_to", "").strip(),
        "close_date_from": request.args.get("close_date_from", "").strip(),
        "close_date_to": request.args.get("close_date_to", "").strip(),
        "audit_year": request.args.get("audit_year", "").strip(),
        "audit_quarter": request.args.get("audit_quarter", "").strip(),
        "quarter_curator_direction": request.args.get("quarter_curator_direction", "").strip(),
        "status": request.args.get("status", "").strip(),
        "project_type": request.args.get("project_type", "").strip(),
        "base_bank": request.args.get("base_bank", "").strip(),
        "curator": request.args.get("curator", "").strip(),
        "product_owner": request.args.get("product_owner", "").strip(),
    }

    open_date_from = parse_date_param("open_date_from")
    open_date_to = parse_date_param("open_date_to")
    close_date_from = parse_date_param("close_date_from")
    close_date_to = parse_date_param("close_date_to")

    if open_date_from and open_date_to and open_date_from > open_date_to:
        open_date_from, open_date_to = open_date_to, open_date_from

    if close_date_from and close_date_to and close_date_from > close_date_to:
        close_date_from, close_date_to = close_date_to, close_date_from

    selected_quarter = get_selected_audit_quarter(
        selected_filters["audit_quarter"],
        audit_quarters,
    )
    audit_year_start, audit_year_end = get_audit_year_period(
        selected_filters["audit_year"],
        audit_quarters,
    )

    query = Project.query

    if open_date_from:
        query = query.filter(Project.agile_open_date >= open_date_from)
    if open_date_to:
        query = query.filter(Project.agile_open_date <= open_date_to)

    if close_date_from:
        query = query.filter(Project.agile_close_date >= close_date_from)
    if close_date_to:
        query = query.filter(Project.agile_close_date <= close_date_to)

    # Аудиторский год / квартал применяем к дате закрытия проекта на внутреннем Agile BL.
    # Если выбран конкретный квартал, он точнее года и используется первым.
    if selected_quarter:
        query = query.filter(Project.agile_close_date >= selected_quarter["start"])
        query = query.filter(Project.agile_close_date <= selected_quarter["end"])
    elif audit_year_start and audit_year_end:
        query = query.filter(Project.agile_close_date >= audit_year_start)
        query = query.filter(Project.agile_close_date <= audit_year_end)

    if selected_filters["status"]:
        query = query.filter(Project.status == selected_filters["status"])
    if selected_filters["project_type"]:
        query = query.filter(Project.project_type == selected_filters["project_type"])
    if selected_filters["base_bank"]:
        query = query.filter(Project.base_bank == selected_filters["base_bank"])
    if selected_filters["curator"]:
        query = query.filter(Project.curator == selected_filters["curator"])
    if selected_filters["product_owner"]:
        query = query.filter(Project.product_owner == selected_filters["product_owner"])

    return (
        query,
        selected_filters,
        open_date_from,
        open_date_to,
        close_date_from,
        close_date_to,
        audit_quarters,
    )

def collect_staff_numbers(projects: list[Project]) -> set[str]:
    staff_numbers: set[str] = set()
    for project in projects:
        for value in (project.curator, project.product_owner):
            if value:
                staff_numbers.add(str(value).strip())
        if project.team:
            staff_numbers.update(
                item.strip() for item in project.team.split(";") if item.strip()
            )
    return staff_numbers


def get_distinct_staff_values(column) -> list[str]:
    values = {
        str(row[0]).strip()
        for row in Project.query.with_entities(column).distinct().all()
        if row[0]
    }
    return sorted(values)


def get_name_map(staff_numbers: set[str]) -> dict[str, str]:
    staff_numbers = {str(number).strip() for number in staff_numbers if number}
    if not staff_numbers:
        return {}

    name_map: dict[str, str] = {}

    users = Users.query.filter(Users.staff_number.in_(staff_numbers)).all()
    for user in users:
        if user.full_name:
            name_map[user.staff_number] = user.full_name

    employees = Employee.query.filter(Employee.staff_number.in_(staff_numbers)).all()
    for employee in employees:
        if employee.full_name:
            name_map[employee.staff_number] = employee.full_name

    return name_map


def display_person(staff_number: str | None, name_map: dict[str, str]) -> str:
    if not staff_number:
        return "Не указан"
    staff_number = str(staff_number).strip()
    return name_map.get(staff_number, staff_number)


def percent(value: int, total: int) -> float:
    return round((value / total) * 100, 1) if total else 0


def ratio(value: int, max_value: int) -> float:
    return round((value / max_value) * 100, 2) if max_value else 0


def make_counter_items(
    counter: Counter,
    labels: list[str],
    total: int,
    short_labels: dict[str, str] | None = None,
) -> list[dict]:
    max_value = max((counter.get(label, 0) for label in labels), default=0)
    items = []
    for index, label in enumerate(labels):
        value = counter.get(label, 0)
        items.append(
            {
                "label": label,
                "short_label": short_labels.get(label, label) if short_labels else label,
                "value": value,
                "percent": percent(value, total),
                "width": ratio(value, max_value),
                "height": ratio(value, max_value),
                "color": CHART_COLORS[index % len(CHART_COLORS)],
            }
        )
    return items


def make_top_people_items(
    counter: Counter,
    name_map: dict[str, str],
    limit: int = 7,
) -> list[dict]:
    most_common = counter.most_common(limit)
    max_value = max((value for _, value in most_common), default=0)
    items = []
    for staff_number, value in most_common:
        items.append(
            {
                "staff_number": staff_number,
                "label": display_person(staff_number, name_map),
                "value": value,
                "width": ratio(value, max_value),
            }
        )
    return items


def make_bank_participation_items(projects: list[Project]) -> list[dict]:
    counter = Counter()
    for project in projects:
        for field_name, label in BANK_FIELD_LABELS.items():
            if getattr(project, field_name, False):
                counter[label] += 1
    return make_counter_items(counter, list(BANK_FIELD_LABELS.values()), len(projects))


def make_donut_gradient(items: list[dict]) -> str:
    total = sum(item["value"] for item in items)
    if not total:
        return "conic-gradient(#e5e7eb 0deg 360deg)"

    start = 0.0
    parts = []
    for item in items:
        value = item["value"]
        if not value:
            continue
        end = start + (value / total) * 360
        parts.append(f"{item['color']} {round(start, 2)}deg {round(end, 2)}deg")
        start = end

    return "conic-gradient(" + ", ".join(parts) + ")"


def get_month_starts(month_count: int = 6, end_date: date | None = None) -> list[date]:
    month = (end_date or date.today()).replace(day=1)
    months = []
    for _ in range(month_count):
        months.append(month)
        if month.month == 1:
            month = date(month.year - 1, 12, 1)
        else:
            month = date(month.year, month.month - 1, 1)
    return list(reversed(months))


def make_svg_points(values: list[int], max_value: int) -> tuple[str, list[dict]]:
    width = 560
    height = 185
    padding_x = 24
    padding_y = 24
    chart_width = width - padding_x * 2
    chart_height = height - padding_y * 2
    max_value = max(max_value, 1)

    points = []
    for index, value in enumerate(values):
        if len(values) == 1:
            x = width / 2
        else:
            x = padding_x + (chart_width / (len(values) - 1)) * index
        y = height - padding_y - (value / max_value) * chart_height
        points.append({"x": round(x, 2), "y": round(y, 2), "value": value})

    polyline = " ".join(f"{point['x']},{point['y']}" for point in points)
    return polyline, points


def make_month_dynamics(projects: list[Project], date_to: date | None = None) -> dict:
    months = get_month_starts(6, date_to)
    month_keys = [(month.year, month.month) for month in months]

    opened_counter = Counter()
    closed_counter = Counter()

    for project in projects:
        if project.agile_open_date:
            opened_counter[(project.agile_open_date.year, project.agile_open_date.month)] += 1
        if project.agile_close_date:
            closed_counter[(project.agile_close_date.year, project.agile_close_date.month)] += 1

    opened_values = [opened_counter.get(key, 0) for key in month_keys]
    closed_values = [closed_counter.get(key, 0) for key in month_keys]
    max_value = max(opened_values + closed_values + [1])

    opened_polyline, opened_points = make_svg_points(opened_values, max_value)
    closed_polyline, closed_points = make_svg_points(closed_values, max_value)

    return {
        "labels": [f"{RU_MONTHS[month.month - 1]} '{str(month.year)[2:]}" for month in months],
        "opened_values": opened_values,
        "closed_values": closed_values,
        "opened_polyline": opened_polyline,
        "closed_polyline": closed_polyline,
        "opened_points": opened_points,
        "closed_points": closed_points,
        "max_value": max_value,
    }



def normalize_staff_number(value) -> str:
    """
    Возвращает только цифры табельного номера.

    Нули слева не отбрасываем, потому что табельный может быть вида 02818384.
    """
    if value is None:
        return ""

    return re.sub(r"\D", "", str(value).strip())


def staff_number_variants(value) -> set[str]:
    """
    Возвращает варианты табельного номера для безопасного сравнения.

    Это нужно на случай, если где-то табельный сохранился без ведущего нуля:
    2818384 должен совпасть с 02818384.
    """
    normalized = normalize_staff_number(value)
    if not normalized:
        return set()

    variants = {normalized}
    if len(normalized) < 8:
        variants.add(normalized.zfill(8))

    return variants


def extract_staff_numbers(value) -> set[str]:
    """
    Достает один или несколько табельных номеров из поля куратора.

    Поддерживает варианты:
    - "02818384";
    - "02818384;29483814";
    - "02818384, 29483814";
    - "02818384 / 29483814".

    Если в проекте указаны два куратора разных направлений, проект будет
    засчитан в выбранное направление, если совпал хотя бы один куратор.
    """
    if not value:
        return set()

    tokens = re.findall(r"\d+", str(value))
    result: set[str] = set()
    for token in tokens:
        result.update(staff_number_variants(token))

    return result


def get_curator_direction_label(direction_code: str | None) -> str:
    direction_code = (direction_code or "").strip()
    if not direction_code:
        return ""

    direction = CURATOR_DIRECTIONS.get(direction_code)
    if not direction:
        return ""

    return direction["label"]


def project_matches_quarter_curator_direction(
    project: Project,
    selected_filters: dict | None = None,
) -> bool:
    """
    Фильтр направления куратора только для графика Agile BL → BL СВА.

    Не применяется к KPI, общей выборке, базовым банкам, ТБ-участникам и другим
    диаграммам. Если в project.curator указано несколько кураторов, достаточно
    совпадения хотя бы одного табельного номера с пулом выбранного направления.
    """
    selected_filters = selected_filters or {}
    direction_code = (selected_filters.get("quarter_curator_direction") or "").strip()

    if not direction_code:
        return True

    direction = CURATOR_DIRECTIONS.get(direction_code)
    if not direction:
        return True

    direction_staff_numbers: set[str] = set()
    for staff_number in direction["staff_numbers"]:
        direction_staff_numbers.update(staff_number_variants(staff_number))

    if not direction_staff_numbers:
        return True

    project_curators = extract_staff_numbers(project.curator)
    if not project_curators:
        return False

    return bool(project_curators & direction_staff_numbers)


def get_visible_audit_quarters(
    audit_quarters: list[dict],
    selected_filters: dict | None = None,
) -> list[dict]:
    """
    Возвращает аудиторские кварталы с учетом выбранных фильтров.

    Если выбран конкретный квартал, он приоритетнее года. Это защищает от ситуации,
    когда в config.yaml у квартала случайно указан не тот year, но код квартала выбран правильно.
    """
    selected_filters = selected_filters or {}
    selected_year = (selected_filters.get("audit_year") or "").strip()
    selected_quarter_code = (selected_filters.get("audit_quarter") or "").strip()

    if selected_quarter_code:
        return [
            item
            for item in audit_quarters
            if item.get("code") == selected_quarter_code
        ]

    if selected_year:
        return [
            item
            for item in audit_quarters
            if item.get("year") == selected_year
        ]

    return audit_quarters

def make_quarter_flow_items(projects: list[Project], audit_quarters: list[dict], selected_filters: dict | None = None) -> list[dict]:
    visible_quarters = get_visible_audit_quarters(audit_quarters, selected_filters)

    quarter_rows = []
    max_value = 0

    for quarter in visible_quarters:
        quarter_projects = [
            project
            for project in projects
            if date_in_period(project.agile_close_date, quarter["start"], quarter["end"])
            and is_internal_agile_closed(project)
            and project_matches_quarter_curator_direction(project, selected_filters)
        ]

        closed_count = len(quarter_projects)
        released_count = sum(1 for project in quarter_projects if is_released_to_sva_backlog(project))
        planned_count = sum(1 for project in quarter_projects if is_planned_to_sva_backlog(project))
        not_released_count = max(closed_count - released_count - planned_count, 0)
        max_value = max(max_value, closed_count, released_count, planned_count, not_released_count)

        quarter_rows.append(
            {
                "code": quarter["code"],
                "label": quarter["label"],
                "period": quarter["period"],
                "year": quarter["year"],
                "closed": closed_count,
                "released": released_count,
                "planned": planned_count,
                "not_released": not_released_count,
            }
        )

    for row in quarter_rows:
        row["closed_width"] = ratio(row["closed"], max_value)
        row["released_width"] = ratio(row["released"], max_value)
        row["planned_width"] = ratio(row["planned"], max_value)
        row["not_released_width"] = ratio(row["not_released"], max_value)

    return quarter_rows


def get_project_participant_banks(project: Project, include_base_bank: bool = True) -> set[str]:
    """
    Возвращает ТБ, участвующие в проекте.

    В матрице коллабораций один проект может быть засчитан нескольким банкам:
    базовому банку и всем банкам, отмеченным в блоке "Банки-участники".
    """
    banks: set[str] = set()

    if include_base_bank and project.base_bank:
        banks.add(str(project.base_bank).strip())

    for field_name, label in BANK_FIELD_LABELS.items():
        if getattr(project, field_name, False):
            banks.add(label)

    return banks


def make_participant_bank_quarter_matrix(
    projects: list[Project],
    audit_quarters: list[dict],
    selected_filters: dict | None = None,
) -> dict:
    """
    Матрица "ТБ-участник x аудиторский квартал".

    В отличие от графика по базовым банкам, здесь один проект может попасть сразу
    в несколько строк, если он был совместным для нескольких банков-участников.
    Считаются проекты, закрытые на внутреннем Agile Backlog.
    """
    visible_quarters = get_visible_audit_quarters(audit_quarters, selected_filters)

    max_value = 0
    rows = []

    for _, bank_label in BANK_FIELD_LABELS.items():
        cells = []
        row_total = 0

        for quarter in visible_quarters:
            value = 0

            for project in projects:
                if not is_internal_agile_closed(project):
                    continue

                if not date_in_period(project.agile_close_date, quarter["start"], quarter["end"]):
                    continue

                if bank_label in get_project_participant_banks(project, include_base_bank=True):
                    value += 1

            row_total += value
            max_value = max(max_value, value)
            cells.append(
                {
                    "quarter": quarter["label"],
                    "value": value,
                    "intensity": 0,
                    "opacity": "0",
                }
            )

        rows.append(
            {
                "bank": bank_label,
                "cells": cells,
                "total": row_total,
            }
        )

    for row in rows:
        for cell in row["cells"]:
            if max_value and cell["value"]:
                cell["intensity"] = round((cell["value"] / max_value) * 100)
                cell["opacity"] = str(round(0.10 + (cell["value"] / max_value) * 0.35, 2))
            else:
                cell["intensity"] = 0
                cell["opacity"] = "0"

    return {
        "columns": visible_quarters,
        "rows": rows,
        "max_value": max_value,
    }


def make_quarter_project_rows(projects: list[Project], audit_quarters: list[dict], name_map: dict[str, str]) -> list[list]:
    rows = []
    for project in projects:
        if not is_internal_agile_closed(project):
            continue

        quarter = next(
            (
                item
                for item in audit_quarters
                if date_in_period(project.agile_close_date, item["start"], item["end"])
            ),
            None,
        )
        if not quarter:
            continue

        if is_released_to_sva_backlog(project):
            category = "Вышел на BL СВА"
        elif is_planned_to_sva_backlog(project):
            category = "Планируется выход на BL СВА"
        else:
            category = "Не вышел на BL СВА"

        rows.append(
            [
                quarter["label"],
                project.project_number,
                project.title,
                project.status,
                format_excel_date(project.agile_open_date),
                format_excel_date(project.agile_close_date),
                project.rating_id or "",
                project.sprint_id or "",
                format_excel_date(project.backlog_date),
                category,
                display_person(project.curator, name_map),
            ]
        )

    return rows


def deadline_payload(project: Project, today: date) -> dict:
    if not project.deadline:
        return {"date": "—", "text": "нет даты", "class": "deadline-muted", "days": 9999}

    days = (project.deadline - today).days
    if days < 0:
        text = f"-{abs(days)} дн."
        css_class = "deadline-danger"
    elif days == 0:
        text = "сегодня"
        css_class = "deadline-warning"
    elif days <= 7:
        text = f"через {days} дн."
        css_class = "deadline-warning"
    else:
        text = f"через {days} дн."
        css_class = "deadline-muted"

    return {
        "date": project.deadline.strftime("%d.%m.%Y"),
        "text": text,
        "class": css_class,
        "days": days,
    }


def make_attention_items(
    projects: list[Project],
    name_map: dict[str, str],
    limit: int | None = 15,
) -> list[dict]:
    today = date.today()
    rows = []

    for project in projects:
        is_active = project.status != FINISHED_STATUS
        problems = []

        if is_active and project.deadline:
            days_to_deadline = (project.deadline - today).days
            if days_to_deadline < 0:
                problems.append((1, "Просрочен дедлайн", "problem-danger"))
            elif days_to_deadline <= 7:
                problems.append((2, "Дедлайн менее 7 дней", "problem-warning"))

        if is_active and (
            project.status == WAITING_RATING_STATUS
            or (project.project_type != "P" and not project.rating_id)
        ):
            problems.append((3, "Нет ID рейтинга ТБ", "problem-warning"))

        if project.status == WAITING_BACKLOG_STATUS and not project.backlog_date:
            problems.append((4, "Не заполнен Backlog СВА", "problem-warning"))

        if is_active and (project.tech_extensions or 0) > 0:
            problems.append((5, "Техническое продление", "problem-info"))

        if not problems:
            continue

        _, problem_text, problem_class = sorted(problems, key=lambda item: item[0])[0]
        deadline = deadline_payload(project, today)

        rows.append(
            {
                "project_number": project.project_number,
                "title": project.title,
                "status": project.status,
                "status_class": STATUS_BADGE_CLASSES.get(project.status, "status-default"),
                "deadline": deadline["date"],
                "deadline_text": deadline["text"],
                "deadline_class": deadline["class"],
                "deadline_days": deadline["days"],
                "problem": problem_text,
                "problem_class": problem_class,
                "curator": display_person(project.curator, name_map),
                "url": url_for("project_new.view_project", project_id=project.id),
            }
        )

    rows.sort(key=lambda item: (item["deadline_days"], item["project_number"]))
    if limit is None:
        return rows
    return rows[:limit]


def make_quality_metrics(projects: list[Project]) -> list[dict]:
    active_projects = [project for project in projects if project.status != FINISHED_STATUS]
    return [
        {
            "label": "Нет ID рейтинга ТБ",
            "value": sum(
                1
                for project in active_projects
                if project.project_type != "P" and not project.rating_id
            ),
            "hint": "кроме P-спринтов",
        },
        {
            "label": "Нет ID спринта",
            "value": sum(1 for project in active_projects if not project.sprint_id),
            "hint": "активные проекты",
        },
        {
            "label": "Нет даты Backlog",
            "value": sum(
                1
                for project in projects
                if project.status == WAITING_BACKLOG_STATUS and not project.backlog_date
            ),
            "hint": "ожидают Backlog СВА",
        },
        {
            "label": "Нет протокола закрытия",
            "value": sum(
                1
                for project in projects
                if project.status == FINISHED_STATUS and not project.close_protocol
            ),
            "hint": "завершенные проекты",
        },
    ]


def build_filter_options() -> dict:
    curator_values = get_distinct_staff_values(Project.curator)
    owner_values = get_distinct_staff_values(Project.product_owner)
    name_map = get_name_map(set(curator_values) | set(owner_values))

    def person_options(values: list[str]) -> list[dict]:
        options = [
            {"value": value, "label": display_person(value, name_map)}
            for value in values
        ]
        return sorted(options, key=lambda item: item["label"])

    audit_quarters = get_audit_quarters()

    return {
        "statuses": FILTER_PROJECT_STATUSES,
        "types": FILTER_PROJECT_TYPES,
        "base_banks": FILTER_BASE_BANKS,
        "curators": person_options(curator_values),
        "product_owners": person_options(owner_values),
        "audit_years": get_audit_years(audit_quarters),
        "audit_quarters": audit_quarters,
        "curator_directions": [
            {
                "value": code,
                "label": direction["label"],
                "staff_numbers": ", ".join(sorted(direction["staff_numbers"])),
            }
            for code, direction in CURATOR_DIRECTIONS.items()
        ],
    }


@analytics_bp.route("/")
@login_required
def dashboard():
    query, selected_filters, _, _, _, close_date_to, audit_quarters = build_analytics_query()
    projects = query.order_by(Project.id.desc()).all()

    today = date.today()
    total_projects = len(projects)
    status_counter = Counter(project.status for project in projects)
    type_counter = Counter(project.project_type for project in projects)
    base_bank_counter = Counter(project.base_bank for project in projects)
    tech_type_counter = Counter(
        project.project_type
        for project in projects
        if project.status == TECH_EXTENSION_STATUS or (project.tech_extensions or 0) > 0
    )

    active_projects = [project for project in projects if project.status != FINISHED_STATUS]
    delayed_ids = {
        project.id
        for project in active_projects
        if project.status == OVERDUE_STATUS or (project.deadline and project.deadline < today)
    }
    deadline_7_ids = {
        project.id
        for project in active_projects
        if project.deadline and today <= project.deadline <= today + timedelta(days=7)
    }
    tech_extension_ids = {
        project.id
        for project in projects
        if project.status == TECH_EXTENSION_STATUS or (project.tech_extensions or 0) > 0
    }

    kpis = [
        {"title": "Всего проектов", "value": total_projects, "icon": "📁", "theme": "blue"},
        {"title": "В работе", "value": status_counter.get(WORK_STATUS, 0), "icon": "🔄", "theme": "blue"},
        {"title": "Завершено", "value": status_counter.get(FINISHED_STATUS, 0), "icon": "✅", "theme": "green"},
        {"title": "Задерживается", "value": len(delayed_ids), "icon": "⏰", "theme": "red"},
        {"title": "Дедлайн 7 дней", "value": len(deadline_7_ids), "icon": "📅", "theme": "orange"},
        {"title": "Тех. продление", "value": len(tech_extension_ids), "icon": "⌛", "theme": "violet"},
        {"title": "Ожидают ID ТБ", "value": status_counter.get(WAITING_RATING_STATUS, 0), "icon": "🪪", "theme": "yellow"},
        {"title": "Ожидают Backlog", "value": status_counter.get(WAITING_BACKLOG_STATUS, 0), "icon": "📋", "theme": "teal"},
    ]

    status_items = make_counter_items(
        status_counter,
        FILTER_PROJECT_STATUSES,
        total_projects,
        STATUS_SHORT_LABELS,
    )
    type_items = make_counter_items(type_counter, FILTER_PROJECT_TYPES, total_projects)
    base_bank_items = make_counter_items(base_bank_counter, FILTER_BASE_BANKS, total_projects)
    bank_participation_items = make_bank_participation_items(projects)
    tech_by_type_items = make_counter_items(
        tech_type_counter,
        FILTER_PROJECT_TYPES,
        sum(tech_type_counter.values()),
    )

    staff_numbers = collect_staff_numbers(projects)
    name_map = get_name_map(staff_numbers)

    curator_counter = Counter(project.curator for project in projects if project.curator)
    owner_counter = Counter(project.product_owner for project in projects if project.product_owner)

    curator_load_items = make_top_people_items(curator_counter, name_map)
    owner_load_items = make_top_people_items(owner_counter, name_map)

    attention_items = make_attention_items(projects, name_map, limit=15)
    quality_metrics = make_quality_metrics(projects)
    month_dynamics = make_month_dynamics(projects, close_date_to)
    quarter_flow_items = make_quarter_flow_items(projects, audit_quarters, selected_filters)
    participant_bank_quarter_matrix = make_participant_bank_quarter_matrix(
        projects,
        audit_quarters,
        selected_filters,
    )

    return render_template(
        "analytics/dashboard.html",
        kpis=kpis,
        status_items=status_items,
        type_items=type_items,
        base_bank_items=base_bank_items,
        bank_participation_items=bank_participation_items,
        tech_by_type_items=tech_by_type_items,
        donut_gradient=make_donut_gradient(type_items),
        curator_load_items=curator_load_items,
        owner_load_items=owner_load_items,
        attention_items=attention_items,
        quality_metrics=quality_metrics,
        month_dynamics=month_dynamics,
        quarter_flow_items=quarter_flow_items,
        participant_bank_quarter_matrix=participant_bank_quarter_matrix,
        filter_options=build_filter_options(),
        selected_filters=selected_filters,
        selected_quarter_direction_label=get_curator_direction_label(
            selected_filters.get("quarter_curator_direction")
        ),
        query_string=request.query_string.decode("utf-8"),
    )


@analytics_bp.route("/export/attention")
@login_required
def export_attention():
    query, _, _, _, _, _, _ = build_analytics_query()
    projects = query.order_by(Project.id.desc()).all()
    name_map = get_name_map(collect_staff_numbers(projects))
    attention_items = make_attention_items(projects, name_map, limit=None)

    output = io.StringIO()
    writer = csv.writer(output, delimiter=";")
    writer.writerow(["Номер проекта", "Название", "Статус", "Дедлайн", "Проблема", "Куратор"])

    for item in attention_items:
        writer.writerow(
            [
                item["project_number"],
                item["title"],
                item["status"],
                item["deadline"],
                item["problem"],
                item["curator"],
            ]
        )

    csv_content = "\ufeff" + output.getvalue()
    return Response(
        csv_content,
        mimetype="text/csv; charset=utf-8",
        headers={
            "Content-Disposition": "attachment; filename=analytics_attention.csv"
        },
    )


# ===== Excel export with native Excel charts =====

EXCEL_MIME_TYPE = "application/vnd.openxmlformats-officedocument.spreadsheetml.sheet"


def format_excel_date(value) -> str:
    if not value:
        return ""
    if isinstance(value, datetime):
        value = value.date()
    return value.strftime("%d.%m.%Y")


def format_filter_value(value: str | None, empty_label: str = "Все") -> str:
    value = (value or "").strip()
    return value if value else empty_label


def write_sheet_title(ws, title: str, subtitle: str | None = None):
    ws.merge_cells("A1:H1")
    ws["A1"] = title
    ws["A1"].font = Font(size=18, bold=True, color="1F2937")
    ws["A1"].alignment = Alignment(vertical="center")
    ws.row_dimensions[1].height = 28
    if subtitle:
        ws.merge_cells("A2:H2")
        ws["A2"] = subtitle
        ws["A2"].font = Font(size=11, color="64748B")


def set_common_sheet_style(ws):
    ws.sheet_view.showGridLines = False
    ws.freeze_panes = "A4"


def style_range_fill(ws, cell_range: str, fill_color: str):
    fill = PatternFill("solid", fgColor=fill_color)
    for row in ws[cell_range]:
        for cell in row:
            cell.fill = fill


def write_excel_table(
    ws,
    start_row: int,
    start_col: int,
    headers: list[str],
    rows: list[list],
    title: str | None = None,
) -> int:
    thin = Side(style="thin", color="E5E7EB")
    border = Border(left=thin, right=thin, top=thin, bottom=thin)

    row = start_row
    if title:
        end_col = start_col + len(headers) - 1
        ws.merge_cells(
            start_row=row,
            start_column=start_col,
            end_row=row,
            end_column=end_col,
        )
        cell = ws.cell(row=row, column=start_col, value=title)
        cell.font = Font(bold=True, size=12, color="1F2937")
        cell.fill = PatternFill("solid", fgColor="F8FAFC")
        cell.alignment = Alignment(vertical="center")
        row += 1

    for offset, header in enumerate(headers):
        cell = ws.cell(row=row, column=start_col + offset, value=header)
        cell.font = Font(bold=True, color="FFFFFF")
        cell.fill = PatternFill("solid", fgColor="2563EB")
        cell.alignment = Alignment(horizontal="center", vertical="center")
        cell.border = border

    for row_index, row_values in enumerate(rows, start=row + 1):
        for offset, value in enumerate(row_values):
            cell = ws.cell(row=row_index, column=start_col + offset, value=value)
            cell.border = border
            cell.alignment = Alignment(vertical="top", wrap_text=True)
            if row_index % 2 == 0:
                cell.fill = PatternFill("solid", fgColor="F8FAFC")

    return row + len(rows) + 2


def autosize_columns(ws, min_width: int = 10, max_width: int = 34):
    for column_cells in ws.columns:
        column_letter = get_column_letter(column_cells[0].column)
        max_length = 0
        for cell in column_cells:
            if cell.value is None:
                continue
            max_length = max(max_length, len(str(cell.value)))
        ws.column_dimensions[column_letter].width = min(
            max(max_length + 2, min_width),
            max_width,
        )


def add_single_series_chart(
    chart_sheet,
    data_sheet,
    anchor: str,
    title: str,
    table_start_row: int,
    row_count: int,
    chart_type: str = "col",
    width: float = 14,
    height: float = 8,
):
    if row_count <= 0:
        return

    chart = BarChart()
    chart.type = chart_type
    chart.style = 10
    chart.title = title
    chart.width = width
    chart.height = height
    chart.legend = None
    chart.y_axis.title = "Количество" if chart_type == "col" else None
    chart.x_axis.title = None if chart_type == "col" else "Количество"

    data = Reference(
        data_sheet,
        min_col=2,
        min_row=table_start_row,
        max_row=table_start_row + row_count,
    )
    categories = Reference(
        data_sheet,
        min_col=1,
        min_row=table_start_row + 1,
        max_row=table_start_row + row_count,
    )
    chart.add_data(data, titles_from_data=True)
    chart.set_categories(categories)
    chart_sheet.add_chart(chart, anchor)


def add_doughnut_chart(
    chart_sheet,
    data_sheet,
    anchor: str,
    title: str,
    table_start_row: int,
    row_count: int,
):
    if row_count <= 0:
        return

    chart = DoughnutChart()
    chart.title = title
    chart.width = 14
    chart.height = 8
    chart.holeSize = 55
    chart.firstSliceAng = 270

    data = Reference(
        data_sheet,
        min_col=2,
        min_row=table_start_row,
        max_row=table_start_row + row_count,
    )
    categories = Reference(
        data_sheet,
        min_col=1,
        min_row=table_start_row + 1,
        max_row=table_start_row + row_count,
    )
    chart.add_data(data, titles_from_data=True)
    chart.set_categories(categories)
    chart_sheet.add_chart(chart, anchor)


def add_month_line_chart(
    chart_sheet,
    data_sheet,
    anchor: str,
    title: str,
    table_start_row: int,
    row_count: int,
):
    if row_count <= 0:
        return

    chart = LineChart()
    chart.title = title
    chart.style = 13
    chart.width = 14
    chart.height = 8
    chart.y_axis.title = "Количество"

    data = Reference(
        data_sheet,
        min_col=2,
        max_col=3,
        min_row=table_start_row,
        max_row=table_start_row + row_count,
    )
    categories = Reference(
        data_sheet,
        min_col=1,
        min_row=table_start_row + 1,
        max_row=table_start_row + row_count,
    )
    chart.add_data(data, titles_from_data=True)
    chart.set_categories(categories)
    chart_sheet.add_chart(chart, anchor)


def add_multi_series_bar_chart(
    chart_sheet,
    data_sheet,
    anchor: str,
    title: str,
    table_start_row: int,
    row_count: int,
    series_count: int,
    width: float = 18,
    height: float = 9,
):
    if row_count <= 0 or series_count <= 0:
        return

    chart = BarChart()
    chart.type = "col"
    chart.style = 10
    chart.title = title
    chart.width = width
    chart.height = height
    chart.y_axis.title = "Количество"
    chart.x_axis.title = "Аудиторский квартал"

    data = Reference(
        data_sheet,
        min_col=2,
        max_col=1 + series_count,
        min_row=table_start_row,
        max_row=table_start_row + row_count,
    )
    categories = Reference(
        data_sheet,
        min_col=1,
        min_row=table_start_row + 1,
        max_row=table_start_row + row_count,
    )
    chart.add_data(data, titles_from_data=True)
    chart.set_categories(categories)
    chart_sheet.add_chart(chart, anchor)


def write_kpi_cards(ws, kpis: list[dict]):
    card_positions = [
        (3, 4), (3, 7), (3, 10), (3, 13),
        (7, 4), (7, 7), (7, 10), (7, 13),
    ]
    fill_by_theme = {
        "blue": "EFF6FF",
        "green": "F0FDF4",
        "red": "FEF2F2",
        "orange": "FFF7ED",
        "violet": "F5F3FF",
        "yellow": "FEFCE8",
        "teal": "F0FDFA",
    }
    border = Border(
        left=Side(style="thin", color="E5E7EB"),
        right=Side(style="thin", color="E5E7EB"),
        top=Side(style="thin", color="E5E7EB"),
        bottom=Side(style="thin", color="E5E7EB"),
    )

    for kpi, (row, col) in zip(kpis, card_positions):
        ws.merge_cells(start_row=row, start_column=col, end_row=row, end_column=col + 1)
        ws.merge_cells(start_row=row + 1, start_column=col, end_row=row + 2, end_column=col + 1)

        title_cell = ws.cell(row=row, column=col, value=f"{kpi['icon']} {kpi['title']}")
        title_cell.font = Font(size=10, bold=True, color="475569")
        title_cell.alignment = Alignment(horizontal="center", vertical="center")

        value_cell = ws.cell(row=row + 1, column=col, value=kpi["value"])
        value_cell.font = Font(size=22, bold=True, color="0F172A")
        value_cell.alignment = Alignment(horizontal="center", vertical="center")

        for r in range(row, row + 3):
            for c in range(col, col + 2):
                cell = ws.cell(row=r, column=c)
                cell.fill = PatternFill(
                    "solid",
                    fgColor=fill_by_theme.get(kpi.get("theme"), "F8FAFC"),
                )
                cell.border = border


def build_excel_context():
    (
        query,
        selected_filters,
        open_date_from,
        open_date_to,
        close_date_from,
        close_date_to,
        audit_quarters,
    ) = build_analytics_query()
    projects = query.order_by(Project.id.desc()).all()

    today = date.today()
    total_projects = len(projects)
    status_counter = Counter(project.status for project in projects)
    type_counter = Counter(project.project_type for project in projects)
    base_bank_counter = Counter(project.base_bank for project in projects)
    tech_type_counter = Counter(
        project.project_type
        for project in projects
        if project.status == TECH_EXTENSION_STATUS or (project.tech_extensions or 0) > 0
    )

    active_projects = [project for project in projects if project.status != FINISHED_STATUS]
    delayed_ids = {
        project.id
        for project in active_projects
        if project.status == OVERDUE_STATUS or (project.deadline and project.deadline < today)
    }
    deadline_7_ids = {
        project.id
        for project in active_projects
        if project.deadline and today <= project.deadline <= today + timedelta(days=7)
    }
    tech_extension_ids = {
        project.id
        for project in projects
        if project.status == TECH_EXTENSION_STATUS or (project.tech_extensions or 0) > 0
    }

    kpis = [
        {"title": "Всего проектов", "value": total_projects, "icon": "📁", "theme": "blue"},
        {"title": "В работе", "value": status_counter.get(WORK_STATUS, 0), "icon": "🔄", "theme": "blue"},
        {"title": "Завершено", "value": status_counter.get(FINISHED_STATUS, 0), "icon": "✅", "theme": "green"},
        {"title": "Задерживается", "value": len(delayed_ids), "icon": "⏰", "theme": "red"},
        {"title": "Дедлайн 7 дней", "value": len(deadline_7_ids), "icon": "📅", "theme": "orange"},
        {"title": "Тех. продление", "value": len(tech_extension_ids), "icon": "⌛", "theme": "violet"},
        {"title": "Ожидают ID ТБ", "value": status_counter.get(WAITING_RATING_STATUS, 0), "icon": "🪪", "theme": "yellow"},
        {"title": "Ожидают Backlog", "value": status_counter.get(WAITING_BACKLOG_STATUS, 0), "icon": "📋", "theme": "teal"},
    ]

    status_items = make_counter_items(status_counter, FILTER_PROJECT_STATUSES, total_projects, STATUS_SHORT_LABELS)
    type_items = make_counter_items(type_counter, FILTER_PROJECT_TYPES, total_projects)
    base_bank_items = make_counter_items(base_bank_counter, FILTER_BASE_BANKS, total_projects)
    bank_participation_items = make_bank_participation_items(projects)
    tech_by_type_items = make_counter_items(tech_type_counter, FILTER_PROJECT_TYPES, sum(tech_type_counter.values()))

    staff_numbers = collect_staff_numbers(projects)
    name_map = get_name_map(staff_numbers)
    curator_counter = Counter(project.curator for project in projects if project.curator)
    owner_counter = Counter(project.product_owner for project in projects if project.product_owner)

    return {
        "projects": projects,
        "selected_filters": selected_filters,
        "open_date_from": open_date_from,
        "open_date_to": open_date_to,
        "close_date_from": close_date_from,
        "close_date_to": close_date_to,
        "kpis": kpis,
        "status_items": status_items,
        "type_items": type_items,
        "base_bank_items": base_bank_items,
        "bank_participation_items": bank_participation_items,
        "tech_by_type_items": tech_by_type_items,
        "month_dynamics": make_month_dynamics(projects, close_date_to),
        "audit_quarters": audit_quarters,
        "quarter_flow_items": make_quarter_flow_items(projects, audit_quarters, selected_filters),
        "participant_bank_quarter_matrix": make_participant_bank_quarter_matrix(
            projects,
            audit_quarters,
            selected_filters,
        ),
        "curator_load_items": make_top_people_items(curator_counter, name_map, limit=10),
        "owner_load_items": make_top_people_items(owner_counter, name_map, limit=10),
        "attention_items": make_attention_items(projects, name_map, limit=None),
        "quality_metrics": make_quality_metrics(projects),
        "name_map": name_map,
    }


@analytics_bp.route("/export/excel")
@login_required
def export_excel():
    context = build_excel_context()
    selected_filters = context["selected_filters"]
    name_map = context["name_map"]

    wb = Workbook()
    ws_dashboard = wb.active
    ws_dashboard.title = "Дашборд"
    ws_data = wb.create_sheet("Данные графиков")
    ws_quarters = wb.create_sheet("Кварталы")
    ws_attention = wb.create_sheet("Требуют внимания")
    ws_quality = wb.create_sheet("Качество данных")

    for sheet in (ws_dashboard, ws_data, ws_quarters, ws_attention, ws_quality):
        set_common_sheet_style(sheet)

    write_sheet_title(
        ws_dashboard,
        "BI-аналитика по проектному портфелю",
        "KPI, диаграммы, аудиторские кварталы и проблемные проекты с учетом выбранных фильтров.",
    )

    selected_quarter = get_selected_audit_quarter(
        selected_filters.get("audit_quarter"),
        context["audit_quarters"],
    )

    filter_rows = [
        ["Дата открытия проекта с", format_excel_date(context["open_date_from"]) or "Все"],
        ["Дата открытия проекта по", format_excel_date(context["open_date_to"]) or "Все"],
        ["Дата закрытия проекта с", format_excel_date(context["close_date_from"]) or "Все"],
        ["Дата закрытия проекта по", format_excel_date(context["close_date_to"]) or "Все"],
        ["Аудиторский год", format_filter_value(selected_filters.get("audit_year"))],
        ["Аудиторский квартал", selected_quarter["label"] if selected_quarter else "Все"],
        [
            "Направление для Agile BL → BL СВА",
            get_curator_direction_label(selected_filters.get("quarter_curator_direction")) or "Все",
        ],
        ["Статус", format_filter_value(selected_filters.get("status"))],
        ["Тип проекта", format_filter_value(selected_filters.get("project_type"))],
        ["Базовый банк", format_filter_value(selected_filters.get("base_bank"))],
        ["Куратор", display_person(selected_filters.get("curator"), name_map) if selected_filters.get("curator") else "Все"],
        ["Product Owner", display_person(selected_filters.get("product_owner"), name_map) if selected_filters.get("product_owner") else "Все"],
    ]
    write_excel_table(ws_dashboard, 3, 1, ["Фильтр", "Значение"], filter_rows, "Примененные фильтры")
    write_kpi_cards(ws_dashboard, context["kpis"])

    current_row = 1
    chart_sources: dict[str, tuple[int, int]] = {}

    def add_source_table(key: str, title: str, rows: list[list], headers: list[str] | None = None):
        nonlocal current_row
        headers = headers or ["Показатель", "Количество"]
        source_start = current_row + 1 if title else current_row
        next_row = write_excel_table(ws_data, current_row, 1, headers, rows, title)
        chart_sources[key] = (source_start, len(rows))
        current_row = next_row + 1

    add_source_table(
        "status",
        "Проекты по статусам",
        [[item["short_label"], item["value"]] for item in context["status_items"]],
    )
    add_source_table(
        "types",
        "Проекты по типам",
        [[item["label"], item["value"]] for item in context["type_items"]],
    )
    add_source_table(
        "base_banks",
        "Проекты по базовым банкам",
        [[item["label"], item["value"]] for item in context["base_bank_items"]],
    )
    md = context["month_dynamics"]
    add_source_table(
        "months",
        "Открыто / закрыто по месяцам",
        [[label, opened, closed] for label, opened, closed in zip(md["labels"], md["opened_values"], md["closed_values"])],
        headers=["Месяц", "Открыто", "Закрыто"],
    )
    add_source_table(
        "curators",
        "Нагрузка по кураторам",
        [[item["label"], item["value"]] for item in context["curator_load_items"]] or [["Нет данных", 0]],
    )
    add_source_table(
        "owners",
        "Нагрузка по Product Owner",
        [[item["label"], item["value"]] for item in context["owner_load_items"]] or [["Нет данных", 0]],
    )
    add_source_table(
        "tech_types",
        "Тех. продления по типам",
        [[item["label"], item["value"]] for item in context["tech_by_type_items"]],
    )
    add_source_table(
        "bank_participation",
        "Банки-участники",
        [[item["label"], item["value"]] for item in context["bank_participation_items"]],
    )
    add_source_table(
        "quarter_flow",
        "Agile BL → BL СВА по аудиторским кварталам",
        [
            [
                item["label"],
                item["closed"],
                item["released"],
                item["planned"],
                item["not_released"],
            ]
            for item in context["quarter_flow_items"]
        ] or [["Нет настроенных кварталов", 0, 0, 0, 0]],
        headers=[
            "Квартал",
            "Закрыто на Agile BL",
            "Вышло на BL СВА",
            "Планируется выход",
            "Не вышло на BL СВА",
        ],
    )

    status_start, status_count = chart_sources["status"]
    type_start, type_count = chart_sources["types"]
    banks_start, banks_count = chart_sources["base_banks"]
    months_start, months_count = chart_sources["months"]
    curators_start, curators_count = chart_sources["curators"]
    owners_start, owners_count = chart_sources["owners"]
    tech_start, tech_count = chart_sources["tech_types"]
    bank_part_start, bank_part_count = chart_sources["bank_participation"]
    quarter_start, quarter_count = chart_sources["quarter_flow"]

    add_single_series_chart(ws_dashboard, ws_data, "A14", "Проекты по статусам", status_start, status_count)
    add_doughnut_chart(ws_dashboard, ws_data, "H14", "Проекты по типам", type_start, type_count)
    add_single_series_chart(ws_dashboard, ws_data, "A30", "Проекты по базовым банкам", banks_start, banks_count)
    add_month_line_chart(ws_dashboard, ws_data, "H30", "Открыто / закрыто по месяцам", months_start, months_count)
    add_single_series_chart(ws_dashboard, ws_data, "A46", "Нагрузка по кураторам", curators_start, curators_count, chart_type="bar")
    add_single_series_chart(ws_dashboard, ws_data, "H46", "Нагрузка по Product Owner", owners_start, owners_count, chart_type="bar")
    add_single_series_chart(ws_dashboard, ws_data, "A62", "Тех. продления по типам", tech_start, tech_count, chart_type="bar")
    add_single_series_chart(ws_dashboard, ws_data, "H62", "Банки-участники", bank_part_start, bank_part_count, chart_type="bar")
    add_multi_series_bar_chart(
        ws_dashboard,
        ws_data,
        "A78",
        "Agile BL → BL СВА по аудиторским кварталам",
        quarter_start,
        quarter_count,
        series_count=4,
        width=28,
        height=10,
    )

    write_sheet_title(ws_quarters, "Статистика по аудиторским кварталам")
    quarter_summary_rows = [
        [
            item["label"],
            item["period"],
            item["closed"],
            item["released"],
            item["planned"],
            item["not_released"],
        ]
        for item in context["quarter_flow_items"]
    ]
    if not quarter_summary_rows:
        quarter_summary_rows = [["", "Кварталы не найдены: проверьте config.yaml или выбранные фильтры", 0, 0, 0, 0]]
    next_quarter_row = write_excel_table(
        ws_quarters,
        4,
        1,
        [
            "Квартал",
            "Период",
            "Закрыто на Agile BL",
            "Вышло на BL СВА",
            "Планируется выход",
            "Не вышло на BL СВА",
        ],
        quarter_summary_rows,
        "Свод по кварталам",
    )

    participant_matrix = context["participant_bank_quarter_matrix"]
    participant_headers = (
        ["ТБ-участник"]
        + [quarter["label"] for quarter in participant_matrix["columns"]]
        + ["Итого"]
    )
    participant_rows = [
        [row["bank"]]
        + [cell["value"] for cell in row["cells"]]
        + [row["total"]]
        for row in participant_matrix["rows"]
    ]
    if not participant_rows:
        participant_rows = [["Нет данных", 0]]

    next_quarter_row = write_excel_table(
        ws_quarters,
        next_quarter_row + 2,
        1,
        participant_headers,
        participant_rows,
        "Количество проектов (ТБ - участники)",
    )

    quarter_project_rows = make_quarter_project_rows(
        context["projects"],
        context["audit_quarters"],
        name_map,
    )
    if not quarter_project_rows:
        quarter_project_rows = [["", "", "Проекты по кварталам не найдены", "", "", "", "", "", "", "", ""]]
    write_excel_table(
        ws_quarters,
        next_quarter_row + 1,
        1,
        [
            "Квартал",
            "Номер проекта",
            "Название",
            "Статус",
            "Дата открытия Agile BL",
            "Дата закрытия Agile BL",
            "ID рейтинга ТБ",
            "ID спринта BL СВА",
            "Дата Backlog СВА",
            "Категория",
            "Куратор",
        ],
        quarter_project_rows,
        "Проекты в квартальной статистике",
    )

    write_sheet_title(ws_attention, "Проекты, требующие внимания")
    attention_rows = [
        [
            item["project_number"],
            item["title"],
            item["status"],
            item["deadline"],
            item["deadline_text"],
            item["problem"],
            item["curator"],
        ]
        for item in context["attention_items"]
    ]
    if not attention_rows:
        attention_rows = [["", "Критичных проектов по выбранным фильтрам не найдено", "", "", "", "", ""]]
    write_excel_table(
        ws_attention,
        4,
        1,
        ["Номер", "Название", "Статус", "Дедлайн", "Осталось", "Проблема", "Куратор"],
        attention_rows,
    )
    ws_attention.auto_filter.ref = f"A4:G{max(5, 4 + len(attention_rows))}"

    write_sheet_title(ws_quality, "Качество заполнения данных")
    quality_rows = [[item["label"], item["value"], item["hint"]] for item in context["quality_metrics"]]
    write_excel_table(ws_quality, 4, 1, ["Проверка", "Количество", "Комментарий"], quality_rows)

    for ws in (ws_dashboard, ws_data, ws_quarters, ws_attention, ws_quality):
        autosize_columns(ws)

    ws_dashboard.column_dimensions["A"].width = 18
    ws_dashboard.column_dimensions["B"].width = 18
    ws_dashboard.column_dimensions["C"].width = 4
    ws_dashboard.column_dimensions["D"].width = 18
    ws_dashboard.column_dimensions["E"].width = 18
    ws_dashboard.column_dimensions["F"].width = 4
    ws_dashboard.column_dimensions["G"].width = 18
    ws_dashboard.column_dimensions["H"].width = 18
    ws_dashboard.column_dimensions["I"].width = 4
    ws_dashboard.column_dimensions["J"].width = 18
    ws_dashboard.column_dimensions["K"].width = 18
    ws_dashboard.column_dimensions["L"].width = 4
    ws_dashboard.column_dimensions["M"].width = 18
    ws_dashboard.column_dimensions["N"].width = 18

    output = io.BytesIO()
    wb.save(output)
    output.seek(0)

    return Response(
        output.getvalue(),
        mimetype=EXCEL_MIME_TYPE,
        headers={
            "Content-Disposition": "attachment; filename=analytics_dashboard.xlsx"
        },
    )
