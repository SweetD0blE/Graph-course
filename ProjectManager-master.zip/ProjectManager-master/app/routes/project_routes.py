from app.extensions import db
from app.forms import CreateProjectForm, EditProjectForm, TechnicalExtensionForm
from app.models import Project, Users
from flask import Blueprint, render_template, redirect, url_for, session, flash, request, abort, jsonify
from flask_login import current_user, login_required
from collections import Counter
from app.utils import check_admin, send_internal_mail
from datetime import date, timedelta
from app.app_logger import logger
from sqlalchemy import or_, cast, String

five_days = date.today() - timedelta(days=5)
project_bp = Blueprint('project_new', __name__)
PROJECTS_PER_PAGE = 10

BANK_FIELDS = [
    "bb",
    "vvb",
    "dvb",
    "mb",
    "pb",
    "szb",
    "sibb",
    "srb",
    "ub",
    "ccb",
    "yuzb",
]

LOCKED_BANK_STATUSES = {
    "Завершен",
    "Ожидает ID в рейтинге ТБ",
    "Ожидает выхода на Backlog СВА",
}

FILTER_PROJECT_STATUSES = [
    "В работе",
    "Завершен",
    "Техническое продление",
    "Задерживается",
    "Ожидает ID в рейтинге ТБ",
    "Ожидает выхода на Backlog СВА",
]

FILTER_PROJECT_TYPES = [
    "I",
    "RnD",
    "I, RnD",
    "P",
    "Доклад",
]

FILTER_BASE_BANKS = [
    "ББ",
    "ВВБ",
    "ДВБ",
    "МБ",
    "ПБ",
    "СЗБ",
    "СибБ",
    "СРБ",
    "УБ",
    "ЦЧБ",
    "ЮЗБ",
]

REPORT_PROJECT_TYPE = "Доклад"

def parse_staff_numbers(value: str | None) -> set[str]:
    """
    Превращает строку табельных номеров через ';' в set.

    Пример:
    '12345678;87654321;' -> {'12345678', '87654321'}
    """
    if not value:
        return set()

    return {
        item.strip()
        for item in value.split(";")    
        if item.strip()
    }

def normalize_staff_numbers(value: str | None) -> str:
    """
    Нормализует список табельных номеров:
    - убирает пробелы;
    - убирает пустые значения;
    - убирает дубли;
    - сохраняет порядок;
    - убирает лишнюю ';' в конце.
    """
    if not value:
        return ""

    result = []
    seen = set()

    for item in value.split(";"):
        staff_number = item.strip()

        if not staff_number:
            continue

        if staff_number in seen:
            continue
        
        result.append(staff_number)
        seen.add(staff_number)

    return ";".join(result)

def get_staff_filter_values(value: str | None) -> list[str]:
    """
    Нормализует значение из фильтра куратора/P.Owner.

    Поддерживает:
    - 02818384
    - 02818384;
    - 02818384;29483814
    - 02818384, 29483814
    """
    if not value:
        return []

    cleaned = (
        str(value)
        .replace(",", ";")
        .replace(" ", ";")
        .strip()
    )

    result = []
    seen = set()

    for item in cleaned.split(";"):
        staff_number = item.strip()

        if not staff_number:
            continue

        if staff_number in seen:
            continue

        result.append(staff_number)
        seen.add(staff_number)

    return result

def staff_field_contains_any(column, staff_numbers: list[str]):
    """
    Проверяет, что поле с табельными номерами через ';'
    содержит хотя бы один табельный номер как отдельный элемент.

    Это защищает от ложных совпадений и от проблемы с лишним ';' в фильтре.
    """
    conditions = []

    for staff_number in staff_numbers:
        conditions.extend([
            column == staff_number,
            column.ilike(f"{staff_number};%"),
            column.ilike(f"%;{staff_number}"),
            column.ilike(f"%;{staff_number};%"),
        ])

    return or_(*conditions) if conditions else None

def is_project_curator(user, project: Project) -> bool:
    """
    Проверяет, является ли пользователь одним из кураторов проекта.
    """
    return user.staff_number in parse_staff_numbers(project.curator)

def is_project_product_owner(user, project: Project) -> bool:
    """
    Проверяет, является ли пользователь одним из P.Owner'ов проекта.
    """
    return user.staff_number in parse_staff_numbers(project.product_owner)

def can_edit_project(user, project: Project) -> bool:
    """
    Единая проверка прав на редактирование проекта.

    Редактировать может:
    - админ;
    - создатель проекта;
    - любой куратор проекта;
    - любой P.Owner проекта.
    """
    if user.status == 1:
        return True

    if project.creator == user.id:
        return True

    if is_project_curator(user, project):
        return True

    if is_project_product_owner(user, project):
        return True

    return False


def banks_are_locked_for_user(project) -> bool:
    """
    Банки нельзя редактировать обычному пользователю,
    если проект находится в закрытом или промежуточном статусе.
    """
    return current_user.status != 1 and project.status in LOCKED_BANK_STATUSES

def snapshot_bank_fields(project) -> dict:
    """
    Сохраняет текущее состояние банков до form.populate_obj(project).
    """
    data = {
        "base_bank": project.base_bank,
    }

    for field_name in BANK_FIELDS:
        data[field_name] = getattr(project, field_name)

    return data

def restore_bank_fields(project, bank_snapshot: dict) -> None:
    """
    Восстанавливает банки после form.populate_obj(project),
    если пользователь не должен был их менять.
    """
    project.base_bank = bank_snapshot["base_bank"]

    for field_name in BANK_FIELDS:
        setattr(project, field_name, bank_snapshot[field_name])

def build_projects_query():
    """
    Собирает базовый query проектов с учетом фильтров главной страницы.
    Используется и для первичной загрузки, и для кнопки "Загрузить ещё".
    """
    query = Project.query

    search = request.args.get("q", "").strip()
    if search:
        search_like = f"%{search}%"

        query = query.filter(
            or_(
                Project.project_number.ilike(search_like),
                Project.title.ilike(search_like),
                Project.project_type.ilike(search_like),
                Project.curator.ilike(search_like),
                Project.product_owner.ilike(search_like),
                Project.team.ilike(search_like),
                Project.status.ilike(search_like),
                Project.base_bank.ilike(search_like),
                Project.km_sup.ilike(search_like),
                cast(Project.rating_id, String).ilike(search_like),
                cast(Project.sprint_id, String).ilike(search_like),
            )
        )
    status = request.args.get("status", "").strip()
    curator = request.args.get("curator", "").strip()
    project_type = request.args.get("project_type", "").strip()
    product_owner = request.args.get("product_owner", "").strip()
    base_bank = request.args.get("base_bank", "").strip()

    curator_numbers = get_staff_filter_values(curator)
    product_owner_numbers = get_staff_filter_values(product_owner)

    if status:
        query = query.filter(Project.status == status)

    if curator_numbers:
        curator_condition = staff_field_contains_any(Project.curator, curator_numbers)

    if curator_condition is not None:
        query = query.filter(curator_condition)

    if project_type:
        query = query.filter(Project.project_type == project_type)

    if product_owner_numbers:
        product_owner_condition = staff_field_contains_any(Project.product_owner, product_owner_numbers)

    if product_owner_condition is not None:
        query = query.filter(product_owner_condition)

    if base_bank:
        query = query.filter(Project.base_bank == base_bank)

    return query

def is_report_project(project_type: str | None) -> bool:
    """
    Проверяет, что проект относится к типу 'Доклад'.
    """
    return project_type == REPORT_PROJECT_TYPE

def apply_report_form_defaults(form) -> None:
    """
    Для проектов типа 'Доклад' синхронизирует поля закрытия
    с полями открытия прямо на уровне формы.

    Это нужно, чтобы validate_dates() и validate_completion()
    работали уже с корректными значениями.
    """
    if not is_report_project(form.project_type.data):
        return

    form.deadline.data = form.agile_open_date.data

    if hasattr(form, "agile_close_date"):
        form.agile_close_date.data = form.agile_open_date.data

    if hasattr(form, "close_protocol"):
        form.close_protocol.data = form.open_protocol.data

def apply_report_project_defaults(project: Project) -> None:
    """
    Для проектов типа 'Доклад' гарантированно выставляет
    закрывающие поля на backend.
    
    Это защита от ситуации, когда JS не сработал или пользователь
    вручную изменил данные в request.
    """
    if not is_report_project(project.project_type):
        return

    project.deadline = project.agile_open_date
    project.agile_close_date = project.agile_open_date
    project.close_protocol = project.open_protocol

def validate_dates(form, page='create'):
    has_errors = False

    if form.agile_open_date.data is not None and (form.agile_open_date.data > form.deadline.data):
        form.agile_open_date.errors.append('Дата открытия проекта не может быть позже Deadline')
        has_errors = True
    
    if (form.backlog_date.data is not None) and form.agile_open_date.data > form.backlog_date.data:
        form.agile_open_date.errors.append('Дата открытия не может быть позже закрытия на Backlog СВА')
        has_errors = True

    if page != 'create':
        if form.agile_close_date.data is not None and (form.agile_open_date.data > form.agile_close_date.data):
            form.agile_open_date.errors.append('Дата открытия не может быть позже даты закрытия')
            has_errors = True
        elif form.backlog_date.data is not None and (form.agile_close_date.data > form.backlog_date.data):
            form.agile_close_date.errors.append('Дата закрытия на Agile Backlog не может позже закрытия на Backlog СВА')
            has_errors = True
        elif form.agile_close_date.data is not None and (form.agile_close_date.data > form.deadline.data):
            form.agile_close_date.errors.append('Дата закрытия на Agile Backlog не может быть позже Deadline')
            has_errors = True
    
    return not has_errors

def validate_completion(form):
    """
    Проверяет обязательные поля для завершения проекта.
    Добавляет ошибки в форму, если поля не заполнены.

    Args:
        form: экземпляр формы

    Returns:
        bool: True, если всё заполнено, иначе False
    """
    required_fields = [
        'title',
        'project_type',
        'curator',
        'product_owner',
        'team',
        'deadline',
        'agile_open_date',
        'open_protocol',
        'agile_close_date',
        'close_protocol',
        'base_bank'
    ]

    mapping = {
        'title': 'Название проекта',
        'project_type': 'Тип проекта',
        'curator': 'Куратор',
        'product_owner': 'P.Owner (спикер)',
        'team': 'Команда',
        'deadline': 'Deadline',
        'agile_open_date': 'Дата открытия на Agile BL',
        'open_protocol': 'Номер протокола (открытие)',
        'agile_close_date': 'Дата закрытия на Agile BL',
        'close_protocol': 'Номер протокола (закрытие)',
        'base_bank': 'Базовый Банк'
    }

    has_errors = False

    for field_name in required_fields:
        field = getattr(form, field_name)
        if not field.data or (isinstance(field.data, str) and not field.data.strip()):
            field.errors.append(f'Поле обязательно для закрытия проекта')
            has_errors = True

    if has_errors:
        flash('Заполните обязательные поля, отмеченные красным', 'warning')

    return not has_errors

def is_empty_value(value):
    """
    Проверяет, что значение пустое.
    Работает и для None, и для пустой строки, и для строки из пробелов.
    """
    return value is None or (isinstance(value, str)) and not value.strip()

def can_complete_without_rating_id(form):
    """
    P-спринты можно завершать без ID проекта в рейтинге ТБ.
    Для остальных типов проектов rating_id обязателен.
    """
    return form.project_type.data == "P"

def check_form(form):

    required_fields = {
        'sprint_id',
        'title',
        'project_type',
        'curator',
        'product_owner',
        'team',
        'deadline',
        'agile_open_date',
        'open_protocol',
        'agile_close_date',
        'close_protocol',
        'base_bank'
    }

    if not can_complete_without_rating_id(form):
        required_fields.add('rating_id')

    for field_name in required_fields:
        field = getattr(form, field_name)

        if is_empty_value(field.data):
            flash('Заполните обязательные поля, отмеченные красным', 'warning')
            field.errors.append('Поле обязательно для закрытия проекта')
            return False
        
    return True

@project_bp.route('/')
def index():
    """
    Главная страница с отображением списка проектов.
    Позволяет фильтровать проекты по статусу и куратору.
    Первично загружает только первые 10 проектов.
    
    Возвращает:
        Render шаблона с проектами, статусами и данными о пользователе.
    """
    user = current_user if current_user.is_authenticated else None
    is_admin = check_admin(current_user) if user else False

    query = build_projects_query()

    project_count = query.count()

    status_rows = (
        query.with_entities(Project.status, db.func.count(Project.id))
        .group_by(Project.status)
        .all()
    )
    status_stats = Counter({status: count for status, count in status_rows})

    selected_filters = {
    "q": request.args.get("q", "").strip(),
    "status": request.args.get("status", "").strip(),
    "curator": request.args.get("curator", "").strip(),
    "project_type": request.args.get("project_type", "").strip(),
    "product_owner": request.args.get("product_owner", "").strip(),
    "base_bank": request.args.get("base_bank", "").strip(),
}
    has_active_filters = any(selected_filters.values())

    ordered_query = query.order_by(Project.id.desc())

    if has_active_filters:
        projects = ordered_query.all()
        next_offset = len(projects)
        has_more = False
    else:
        projects = ordered_query.limit(PROJECTS_PER_PAGE).all()
        next_offset = len(projects)
        has_more = project_count > len(projects)

    logger.info(
        f'Пользователь {"аноним" if not user else user.staff_number} '
        f'просмотрел список проектов. Всего проектов: {project_count}'
    )

    return render_template(
        'index.html',
        is_admin=is_admin,
        user=user,
        projects=projects,
        project_count=project_count,
        status_stats=status_stats,
        per_page=PROJECTS_PER_PAGE,
        next_offset=next_offset,
        has_more=has_more,
        filter_project_statuses=FILTER_PROJECT_STATUSES,
        filter_project_types=FILTER_PROJECT_TYPES,
        filter_base_banks=FILTER_BASE_BANKS,
        selected_filters=selected_filters,
    )

@project_bp.route('/projects/load-more')
def load_more_projects():
    """
    AJAX-endpoint для ленивой подгрузки проектов на главной странице.
    Возвращает HTML-строки таблицы и информацию, есть ли ещё проекты.
    """
    offset = request.args.get('offset', 0, type=int)
    limit = request.args.get('limit', PROJECTS_PER_PAGE, type=int)

    offset = max(offset, 0)
    limit = min(max(limit, 1), 50)

    query = build_projects_query().order_by(Project.id.desc())

    total_count = query.count()

    projects = (
        query.offset(offset)
        .limit(limit)
        .all()
    )

    next_offset = offset + len(projects)

    html = render_template(
        'projects/_project_rows.html',
        projects=projects,
    )

    return jsonify({
        'html': html,
        'next_offset': next_offset,
        'has_more': next_offset < total_count,
    })

@project_bp.route('/create', methods=['GET', 'POST'])
@login_required
def create_project():
    """
    Создание нового проекта.
    Доступно только авторизованным пользователям.
    При успешном создании перенаправляет на главную.
    """
    form = CreateProjectForm()

    if request.method == "POST":
        apply_report_form_defaults(form)

    if form.validate_on_submit() and validate_dates(form):
        new_project = Project(
            project_number=Project.generate_project_number(),
            title=form.title.data,
            project_type=form.project_type.data,
            curator=normalize_staff_numbers(form.curator.data),
            product_owner=normalize_staff_numbers(form.product_owner.data),
            team=form.team.data,
            deadline=form.deadline.data,
            agile_open_date=form.agile_open_date.data,
            open_protocol=form.open_protocol.data,
            agile_close_date=form.agile_open_date.data if is_report_project(form.project_type.data) else None,
            close_protocol=form.open_protocol.data if is_report_project(form.project_type.data) else None,
            base_bank=form.base_bank.data,
            bb=form.bb.data,
            vvb=form.vvb.data,
            dvb=form.dvb.data,
            mb=form.mb.data,
            pb=form.pb.data,
            szb=form.szb.data,
            sibb=form.sibb.data,
            srb=form.srb.data,
            ub=form.ub.data,
            ccb=form.ccb.data,
            yuzb=form.yuzb.data,
            creator=current_user.id,
            backlog_date = form.backlog_date.data,
            status='В работе'
        )

        apply_report_project_defaults(new_project)

        db.session.add(new_project)
        db.session.commit()
        logger.info(f'Пользователь {current_user.staff_number} создал проект {new_project.project_number}')
        flash('Проект успешно создан!', 'success')
        return redirect(url_for('project_new.index'))
    else:
        pass

    return render_template('projects/create_project.html', form=form)

@project_bp.route('/edit/<int:project_id>', methods=['GET', 'POST'])
@login_required
def edit_project(project_id):
    """
    Редактирование проекта.
    Разрешено только создателю проекта или администратору.
    Если проект завершен — редактировать может только админ.
    Поддерживает отдельную форму для технического продления.
    """
    project = Project.query.get_or_404(project_id)

    if not can_edit_project(current_user, project):
        logger.warning(
            f'Пользователь {current_user.staff_number} попытался редактировать проект {project.project_number} без прав'
        )
        abort(403)
    
    if project.status == 'Завершен' and current_user.status != 1:
        flash('Проект может изменить только Админ', 'info')
        return redirect(url_for('project_new.view_project', project_id=project_id))
    
    old_user = Users.query.get(project.creator)
    form = EditProjectForm(obj=project)
    extension_form = TechnicalExtensionForm()

    if request.method == "POST":
        apply_report_form_defaults(form)

    if form.validate_on_submit() and validate_dates(form, page='edit'):
        action = request.form.get('action')

        if form.submit.data:
            bank_snapshot = snapshot_bank_fields(project)
            should_restore_banks = banks_are_locked_for_user(project)

            form.populate_obj(project)
            project.curator = normalize_staff_numbers(form.curator.data)
            project.product_owner = normalize_staff_numbers(form.product_owner.data)
            apply_report_project_defaults(project)

            if should_restore_banks:
                restore_bank_fields(project, bank_snapshot)

            db.session.commit()
            logger.info(f'Пользователь {current_user.staff_number} изменил проект {project.project_number}')

            updated_project = Project.query.get(project_id)
            new_user = Users.query.get(updated_project.creator)
            
            if old_user != new_user:
                send_internal_mail(
                    old_user.email,
                    f'Вам пришло это сообщение, так как Администратор изменил управляющего проекта {project.project_number}',
                    f'Изменение управляющего проекта {project.project_number}'
                )
                send_internal_mail(
                    new_user.email,
                    f'Вам пришло это сообщение, так как администратор назначил Вас управляющим проекта {updated_project.project_number}',
                    f'Изменение управляющего проекта {updated_project.project_number}'
                )
                logger.info(f'Изменён управляющий проекта {project.project_number} с {old_user.staff_number} на {new_user.staff_number}')

            flash('Изменения сохранены!', 'success')
            return redirect(url_for('project_new.index'))     
         
        elif action == 'complete':
            if validate_completion(form):
                bank_snapshot = snapshot_bank_fields(project)
                should_restore_banks = banks_are_locked_for_user(project)

                # Все поля заполнены — сохраняем
                form.populate_obj(project)

                project.curator = normalize_staff_numbers(form.curator.data)
                project.product_owner = normalize_staff_numbers(form.product_owner.data)

                # Для "Доклад" синхронизируем поля открытия/закрытия
                apply_report_project_defaults(project)

                if should_restore_banks:
                    restore_bank_fields(project, bank_snapshot)
                
                rating_id_is_empty = is_empty_value(form.rating_id.data)
                can_skip_rating_id = can_complete_without_rating_id(form)

                if rating_id_is_empty and not can_skip_rating_id:          
                    project.status = 'Ожидает ID в рейтинге ТБ'

                elif project.status == 'Ожидает выхода на Backlog СВА':
                    check = check_form(form)

                    if check:
                        project.status = 'Завершен'
                    else:
                        pass
                else:
                    if form.backlog_date.data is None:
                        project.status = 'Завершен'
                    else:
                        project.status = 'Ожидает выхода на Backlog СВА'

                db.session.commit()

                logger.info(f'Пользователь {current_user.staff_number} завершил проект {project.project_number}')
                flash('Проект успешно завершён!', 'success')
                return redirect(url_for('project_new.view_project', project_id=project_id))
            else:
                # Ошибки уже добавлены в форму → шаблон их отобразит
                pass  # просто останемся на странице
    
    if extension_form.submit_extension.data and extension_form.validate_on_submit():
        project.deadline = extension_form.new_deadline.data
        project.tech_extensions += 1
        project.deadline_notified = False
        project.status = 'Техническое продление'
        db.session.commit()

        if old_user:
            send_internal_mail(
                'Agile_Backlog_OAPSO@omega.sbrf.ru',
                f'Пользователь {old_user.full_name} изменил Deadline до {extension_form.new_deadline.data}',
                f'Техническое продление по проекту {project.project_number}'
            )
            logger.info(f'Пользователь {old_user.staff_number} продлил проект {project.project_number} до {extension_form.new_deadline.data}')
        else:
            logger.warning(f'Пользователь не найден при продлении проекта {project.project_number}')
        
        flash('Проект продлен')
        return redirect(url_for('project_new.edit_project', project_id=project_id))

    return render_template(
        'projects/edit_project.html', 
        form=form,
        project=project, 
        extension_form=extension_form,
        user=old_user,
        can_edit=can_edit_project(current_user, project),
    )


@project_bp.route('/project/<int:project_id>')
def view_project(project_id):
    """
    Просмотр детальной информации по проекту.
    Доступно всем пользователям.
    """
    user = current_user if current_user.is_authenticated else None
    is_admin = check_admin(user) if user else False
    
    project = Project.query.get_or_404(project_id)

    display_fields = [
        'project_number',
        'rating_id',
        'km_sup',
        'sprint_id',
        'title',
        'project_type',
        'curator',
        'product_owner',
        'team',
        'deadline',
        'tech_extensions',
        'agile_open_date',
        'open_protocol',
        'agile_close_date',
        'close_protocol',
        'base_bank'
    ]

    project_dict = {field: getattr(project, field) for field in display_fields}

    field_labels = { 
        'project_number' : 'Номер проекта',
        'rating_id' : 'ID проекта в рейтинге ТБ',
        'km_sup' : 'КМ в СУП',
        'sprint_id' : 'ID Спринта в реестре спринтов BL СВА',
        'title' : 'Название проекта',
        'project_type' : 'Тип проекта',
        'curator' : 'Куратор',
        'product_owner' : 'P.Owner (спикер)',
        'team' : 'Команда',
        'deadline' : 'Deadline',
        'tech_extensions' : 'Количество технических продлений',
        'agile_open_date' : 'Дата открытия на Agile BL',
        'open_protocol' : 'Номер протокола (открытие)',
        'agile_close_date' : 'Дата закрытия на Agile BL',
        'close_protocol' : 'Номер протокола (закрытие)',
        'base_bank' : 'Базовый Банк'
    }

    logger.info(f'Пользователь {"аноним" if not user else user.staff_number} просмотрел проект {project.project_number}')

    return render_template(
        'projects/view_project.html', 
        project=project, 
        is_admin=is_admin, 
        field_labels=field_labels,
        display_fields=display_fields,
        project_dict=project_dict
    )
    
# @project_bp.before_request
def notify_if_needed():
    """
    Проверка проектов перед каждым запросом.
    Если дедлайн или дата закрытия просрочены и проект не завершён, меняет статус на 'Задерживается'.
    Отправляет уведомления, если они ещё не были отправлены.
    """

    try:
        deadline_expired = Project.query.filter(
            Project.deadline.isnot(None),
            Project.deadline <= five_days,
            (Project.status != 'Завершен') & (Project.status != 'Ожидает ID в рейтинге ТБ') & (Project.status != 'Ожидает выхода на Backlog СВА')
        ).all()

        close_expired = Project.query.filter(
            Project.agile_close_date.isnot(None),
            Project.agile_close_date <= five_days,
            (Project.status != 'Завершен') & (Project.status != 'Ожидает ID в рейтинге ТБ') & (Project.status != 'Ожидает выхода на Backlog СВА')
        ).all()
        
        if deadline_expired:
            try:
                for project in deadline_expired:
                    user = Users.query.get(project.creator)
                    project.status = 'Задерживается'
                    if user and not project.deadline_notified:
                        send_internal_mail(user.email, f'Проект {project.title} просрочен, пожалуйста, примите меры: оформите техническое продление или закройте проект.', 'Проект просрочен') 
                        project.deadline_notified = True
                        logger.info(f'Уведомление о просрочке deadline для проекта {project.project_number} отправлено пользователю {user.staff_number}')
                db.session.commit()       
            except Exception as e:
                db.session.rollback()
                logger.error(f'При отправке сообщения о просрочке deadline возникла следующая ошибка: {e}')

        if close_expired:
            try:           
                for project in close_expired:
                    user = Users.query.get(project.creator)
                    project.status = 'Задерживается'
                    if user and not project.close_notified:
                        send_internal_mail(user.email, f'Закрытие проекта', f'Проект {project.title} нужно закрыть!')
                        project.close_notified = True
                        logger.info(f'Уведомление о просрочке закрытия проекта {project.project_number} отправлено пользователю {user.staff_number}')
                db.session.commit()
            except Exception as e:
                db.session.rollback()
                logger.error(f'При отправке сообщения о просрочке закрытия проекта возникла следующая ошибка: {e}')
    
    except Exception as e:
        db.session.rollback()
        logger.error(f'Ошибка при проверке проектов: {e}')

def every_week_notificate():
    
    try:
        pkm_expired = Project.query.filter(
            Project.agile_close_date.isnot(None),
            Project.status == 'Ожидает ID в рейтинге ТБ'
        ).all()

        backlog_expired = Project.query.filter(
            Project.backlog_date.isnot(None),
            Project.status == 'Ожидает выхода на Backlog СВА'
        ).all()

        if pkm_expired:
            try:           
                for project in pkm_expired:
                    user = Users.query.get(project.creator)
                    if user:
                        send_internal_mail(user.email, f'Проверка рейтинга ТБ', f'Проверьте, пожалуйста, информацию по проекту: {project.title} в рейтинге ТБ')
                        logger.info(f'Уведомление о проверке рейтинга ТБ {project.project_number} отправлено пользователю {user.staff_number}')
                db.session.commit()
            except Exception as e:
                logger.error(f'При отправке сообщения о проверке рейтинга ТБ возникла следующая ошибка: {e}')

        if backlog_expired:
            try:           
                for project in backlog_expired:
                    user = Users.query.get(project.creator)
                    if user and project.backlog_date > five_days:
                        send_internal_mail(user.email, f'Закрытие проекта', f'Пожалуйста, закройте проект: {project.title}')
                        logger.info(f'Уведомление о закрытии проекта {project.project_number} отправлено пользователю {user.staff_number}')
            except Exception as e:
                logger.error(f'При отправке сообщения о проверке проекта в реестре СВА возникла следующая ошибка: {e}')
    
    except Exception as e:
        db.session.rollback()
        logger.error(f'Ошибка при проверке проектов: {e}')
