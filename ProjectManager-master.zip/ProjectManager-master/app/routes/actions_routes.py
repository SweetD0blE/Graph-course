import pandas as pd
import io, os
from datetime import date
from werkzeug.utils import secure_filename
from flask import redirect, url_for, request, flash, session, send_file, jsonify, Blueprint
from flask_login import current_user, logout_user
from app.extensions import db
from app.models import Project, Employee, Users
from app.utils import check_admin, send_internal_mail, format_period_column
from app.app_logger import logger
from app.forms import FeedBackHelpForm
from sqlalchemy import or_, cast, String
from app.routes.project_routes import get_staff_filter_values, staff_field_contains_any

act_bp = Blueprint('act', __name__)

def get_initials(full_name):
    """
    Преобразует полное ФИО в формат "Фамилия И.О."
    Пример: "Макаров Александр Андреевич" → "Макаров А.А."
    """
    parts = full_name.strip().split()
    if len(parts) < 1:
        return full_name

    surname = parts[0]
    initials = surname

    # Добавляем инициалы для имени и отчества
    for part in parts[1:]:
        if part:  # на случай пустых строк
            initials += f" {part[0]}."

    return initials

def file_prepare(filepath):
    """
    Обрабатывает Excel-файл, нормализует и конвертирует значения для загрузки в БД.

    :param filepath: Путь к Excel-файлу.
    :return: pd.DataFrame с подготовленными значениями.
    """

    df = pd.read_excel(filepath, dtype={'Куратор': str, 'P.Owner (Спикер)': str})
    df = df.iloc[1:].reset_index(drop=True)

    required_columns = [
        'Дата открытия на Agile BL', 'Deadline', 'Дата закрытия на Agile BL',
        'КМ в СУП', 'Куратор', 'P.Owner (Спикер)', 'ID Спринта в реестре спринтов BL СВА',
        'Номер протокола (закрытие)', 'Номер протокола (открытие)', 'ID проекта в рейтинге ТБ',
        'Количество технических продлений', 'ББ', 'ВВБ', 'ДВБ', 'МБ', 'ПБ', 'СЗБ',
        'СРБ', 'СибБ', 'УБ', 'ЦЧБ', 'ЮЗБ'
    ]
    missing = [col for col in required_columns if col not in df.columns]
    if missing:
        logger.error(f'В таблице отсутствуют обязательные колонки: {", ".join(missing)}')
        flash(f'В таблице отсутствуют обязательные колонки: {", ".join(missing)}', 'danger')
        return

    try:
        df['Дата открытия на Agile BL'] = df['Дата открытия на Agile BL'].apply(lambda x: pd.to_datetime(x).date() if pd.notna(x) and str(x).strip() else None)
        df['Deadline'] = df['Deadline'].apply(lambda x: pd.to_datetime(x).date() if pd.notna(x) and str(x).strip() else None)
        df['Дата закрытия на Agile BL'] = df['Дата закрытия на Agile BL'].apply(lambda x: pd.to_datetime(x).date() if pd.notna(x) and str(x).strip() else None)
        df['КМ в СУП'] = df['КМ в СУП'].fillna('')
        df['Куратор'] = df['Куратор'].apply(staff_numbers_cell_validator)
        df['P.Owner (Спикер)'] = df['P.Owner (Спикер)'].apply(staff_numbers_cell_validator)
        df['ID Спринта в реестре спринтов BL СВА'] = df['ID Спринта в реестре спринтов BL СВА'].apply(lambda x: int(x) if pd.notna(x) else None)
        df['Номер протокола (закрытие)'] = df['Номер протокола (закрытие)'].apply(lambda x: int(x) if pd.notna(x) else None)
        df['Номер протокола (открытие)'] = df['Номер протокола (открытие)'].apply(lambda x: int(x) if pd.notna(x) else None)
        df['ID проекта в рейтинге ТБ'] = df['ID проекта в рейтинге ТБ'].apply(lambda x: int(x) if pd.notna(x) else None)
        df['Количество технических продлений'] = df['Количество технических продлений'].fillna(0).astype(int)

        banks = ['ББ', 'ВВБ', 'ДВБ', 'МБ', 'ПБ', 'СЗБ', 'СРБ', 'СибБ', 'УБ', 'ЦЧБ', 'ЮЗБ']
        for col in banks:
            df[col] = df[col].fillna(0).astype(int)

    except Exception as e:
        logger.error(f'Ошибка при импорте данных в Базу Данных: {e}')
        flash('Ошибка в данных импортируемой таблицы', 'danger')

    return df

def staff_numbers_cell_validator(value):
    """
    Форматирует ячейку с одним или несколькими табельными номерами.

    Поддерживает:
    - 12345678
    - 12345678;87654321
    - 12345678;87654321
    """
    if pd.isna(value):
        return ""

    raw_value = str(value).strip()

    if not raw_value or raw_value.lower() == "nan":
        return ""

    parts = [
        item.strip().zfill(8)
        for item in raw_value.split(";")
        if item.strip()
    ]

    return ";".join(dict.fromkeys(parts))

def team_validator(row):
    """
    Форматирует строку с табельными номерами участников команды.

    :param row: Строка с табельными номерами, разделёнными точкой с запятой.
    :return: Строка табельных номеров, дополненных до 8 символов.
    """
    if str(row).lower() != 'nan':
        return ';'.join([tab.zfill(8) for tab in str(row).split(';')]) + ';'
    else:
        return ''

@act_bp.route('/import-employees', methods=['POST'])
def import_employees():
    """
    Импортирует сотрудников из Excel-файла в БД.
    Доступно только администраторам.
    """
    if not check_admin(current_user):
        flash('Доступ запрещен', 'danger')
        return redirect(url_for('project_new.index'))

    file = request.files.get('file_employee')
    if not file:
        flash('Файл не выбран', 'warning')
        return redirect(url_for('project_new.index'))

    try:
        df = pd.read_excel(file)
        existing_employees = {e.staff_number for e in db.session.query(Employee.staff_number).all()}
        for _, row in df.iterrows():
            row_tab = str(row['TAB_NUM']).strip().zfill(8)
            if row_tab not in existing_employees:
                emp = Employee(
                    full_name=row['FIO'],
                    staff_number=row_tab,
                    position=row['JOB_TITLE'],
                    department=row['DEPARTMENT'],
                    email=row['EMAIL']
                )
                db.session.add(emp)
        db.session.commit()
        flash('Импорт завершен', "success")
        logger.info('Данные по сотрудникам были добавлены')

    except Exception as e:
        db.session.rollback()
        flash('Ошибка импорта', 'danger')
        logger.error(f'Ошибка при импорте сотрудников в БД: {e}')

    return redirect(url_for('project_new.index'))

@act_bp.route('/import_excel', methods=['POST'])
def import_excel():
    """
    Импортирует проекты из Excel-файла в БД.
    Доступно только администраторам.
    """
    if not check_admin(current_user):
        flash('Доступ запрещен', 'danger')
        return redirect(url_for('project_new.index'))

    file = request.files.get('file')
    if not file or not file.filename.endswith('.xlsx'):
        flash('Пожалуйста, выберите файл Excel (.xlsx)', 'danger')
        return redirect(url_for('project_new.index'))

    filename = secure_filename(file.filename)
    filepath = os.path.join('instance', filename)
    file.save(filepath)

    try:
        df = file_prepare(filepath)

        for _, row in df.iterrows():
            try:   
                project = Project(
                    project_number=row.get('Номер проекта'),
                    rating_id=row.get('ID проекта в рейтинге ТБ'),
                    km_sup=row.get('КМ в СУП'),
                    sprint_id=row.get('ID Спринта в реестре спринтов BL СВА'),
                    title=row.get('Название проекта'),
                    project_type=row.get('Тип проекта'),
                    curator=row.get('Куратор'),
                    product_owner=row.get('P.Owner (Спикер)'),
                    team=team_validator(row.get('Команда')),
                    deadline=row.get('Deadline'),
                    tech_extensions=row.get('Количество технических продлений'),
                    agile_open_date=row.get('Дата открытия на Agile BL'),
                    open_protocol=row.get('Номер протокола (открытие)'),
                    agile_close_date=row.get('Дата закрытия на Agile BL'),
                    close_protocol=row.get('Номер протокола (закрытие)'),
                    base_bank=row.get('Базовый Банк'),
                    bb=int(row.get('ББ')),
                    vvb=int(row.get('ВВБ')),
                    dvb=int(row.get('ДВБ')),
                    mb=int(row.get('МБ')),
                    pb=int(row.get('ПБ')),
                    szb=int(row.get('СЗБ')),
                    sibb=int(row.get('СибБ')),
                    srb=int(row.get('СРБ')),
                    ub=int(row.get('УБ')),
                    ccb=int(row.get('ЦЧБ')),
                    yuzb=int(row.get('ЮЗБ')),
                    creator=current_user.id,
                    status='Завершен' if row.get('Дата закрытия на Agile BL') is not None and row.get('Дата закрытия на Agile BL') < date.today() else 'В работе'
                )
                db.session.add(project)
            except Exception as e:
                logger.error(f'Ошибка в строке проекта: {e}')

        db.session.commit()
        flash('Импорт завершён успешно!', 'success')
        logger.info('Импорт проектов завершен')

    except Exception as e:
        db.session.rollback()
        flash('Ошибка при импорте', 'danger')
        logger.error(f'Ошибка при импорте проектов: {e}')

    finally:
        try:
            os.remove(filepath)
        except Exception as e:
            logger.error(f'Ошибка удаления файла {filepath}: {e}')

    return redirect(url_for('project_new.index'))

@act_bp.route('/check-employees')
def check_employees():
    """
    Вспомогательный маршрут для отладки:
    отображает всех сотрудников с их ФИО и табельными номерами в виде строки HTML.
    
    Returns:
        str: Список сотрудников в виде HTML-строки.
    """
    employees = Employee.query.all()
    return "<br>".join([f'{e.full_name} - {e.staff_number}' for e in employees])

@act_bp.route('/search_employees')
def search_employees():
    """
    Поиск сотрудников по ФИО, должности или отделу.
    Возвращает максимум 5 результатов с label и значением табельного номера.
    """
    query = request.args.get('q', '').strip()
    if not query:
        return jsonify([])

    # Безопасная фильтрация с использованием ilike, ограничение на 5 результатов
    results = Employee.query.filter(
        (Employee.full_name.ilike(f"%{query}%")) |
        (Employee.department.ilike(f"%{query}%")) |
        (Employee.position.ilike(f"%{query}%"))
    ).limit(5).all()

    return jsonify([
        {
            'label': f"{emp.full_name} ({emp.position}, {emp.department})",
            'value': emp.staff_number
        }
        for emp in results
    ])

@act_bp.route('/search_employee')
def search_employee():
    """
    Поиск сотрудников по ФИО.
    Возвращает максимум 5 результатов с подробными данными.
    """
    query = request.args.get('q', '').strip()
    if not query:
        return jsonify([])

    matches = Employee.query.filter(Employee.full_name.ilike(f'%{query}%')).limit(5).all()

    return jsonify([
        {
            'full_name': emp.full_name,
            'staff_number': emp.staff_number,
            'department': emp.department,
            'position': emp.position,
            'email': emp.email
        }
        for emp in matches
    ])

@act_bp.route('/api/employees')
def get_employees():
    """
    Поиск сотрудников по ФИО (используется в API).
    
    Query Params:
        query (str): строка поиска (приводится к lower).
    
    Returns:
        Response: JSON-массив с результатами поиска (ФИО, табельный, должность, отдел).
    """
    query = request.args.get('query', '').lower()
    if not query:
        return jsonify([])

    results = Employee.query.filter(Employee.full_name.ilike(f'%{query}%')).all()

    return jsonify([
        {
            'full_name': emp.full_name,
            'staff_number': emp.staff_number,
            'position': emp.position,
            'department': emp.department
        }
        for emp in results
    ])


@act_bp.route('/send_feedback', methods=['POST'])
def send_feedback():
    """
    Отправка письма с жалобой/фидбеком через внутреннюю почту.

    Использует send_internal_mail. Отображает flash-сообщение.

    Returns:
        Response: редирект на главную страницу.
    """
    user_mail = current_user.email

    report_form = FeedBackHelpForm()

    if report_form.validate_on_submit():
        reportTheme = report_form.themeReport.data
        bodyReport = report_form.bodyReport.data

        try:
            send_internal_mail('Agile_Backlog_OAPSO@omega.sbrf.ru', f'{bodyReport} - моя почта {user_mail}',
                               f'Ошибка с веб-приложение - {reportTheme}')
            flash('Письмо было отправлено')
            logger.info(f'{current_user} отправил сообщение об ошибке')
            return redirect(request.referrer)
        except Exception as e:
            logger.error(f'Ошибка при отправке сообщения: {e}')
            flash('Письмо не было отправлено из-за внутренней ошибки')

    return redirect(request.referrer or url_for('project_new.index'))

@act_bp.route('/export_filtered', methods=['GET'])
def export_filtered():
    """
    Экспорт отфильтрованных проектов в Excel.

    Использует те же GET-параметры, что и главная страница:
    - q
    - status
    - curator
    - project_type
    - product_owner
    - base_bank

    Важно:
    - q ищет по базе, а не только по загруженным строкам таблицы;
    - curator и product_owner фильтруются как табельные номера через ';',
      чтобы значения вида '02818384;' не ломали выборку.
    """
    query = Project.query

    search = request.args.get("q", "").strip()
    status = request.args.get("status", "").strip()
    curator = request.args.get("curator", "").strip()
    project_type = request.args.get("project_type", "").strip()
    product_owner = request.args.get("product_owner", "").strip()
    base_bank = request.args.get("base_bank", "").strip()

    if search:
        search_like = f"%{search}%"

        query = query.filter(
            or_(
                cast(Project.project_number, String).ilike(search_like),
                Project.title.ilike(search_like),
                Project.project_type.ilike(search_like),
                Project.curator.ilike(search_like),
                Project.product_owner.ilike(search_like),
                Project.team.ilike(search_like),
                Project.status.ilike(search_like),
                Project.base_bank.ilike(search_like),
                Project.km_sup.ilike(search_like),
                cast(Project.rating_id, String).ilike(search_like),
                cast(Project.sprint_id, String).ilike(search_like),
                cast(Project.open_protocol, String).ilike(search_like),
                cast(Project.close_protocol, String).ilike(search_like),
            )
        )

    if status:
        query = query.filter(Project.status == status)

    curator_numbers = get_staff_filter_values(curator)

    if curator_numbers:
        curator_condition = staff_field_contains_any(Project.curator, curator_numbers)

        if curator_condition is not None:
            query = query.filter(curator_condition)

    if project_type:
        query = query.filter(Project.project_type == project_type)

    product_owner_numbers = get_staff_filter_values(product_owner)

    if product_owner_numbers:
        product_owner_condition = staff_field_contains_any(
            Project.product_owner,
            product_owner_numbers,
        )

        if product_owner_condition is not None:
            query = query.filter(product_owner_condition)

    if base_bank:
        query = query.filter(Project.base_bank == base_bank)

    projects = query.order_by(Project.id.desc()).all()

    df = pd.DataFrame([p.to_dict_expt() for p in projects])

    try:
        df = format_period_column(df, 'ID проекта в рейтинге ТБ')
    except Exception as e:
        logger.error(e)

    output = io.BytesIO()

    with pd.ExcelWriter(output, engine='openpyxl') as writer:
        df.to_excel(writer, index=False, sheet_name='Projects')

    output.seek(0)

    return send_file(
        output,
        as_attachment=True,
        download_name='projects.xlsx',
        mimetype='application/vnd.openxmlformats-officedocument.spreadsheetml.sheet',
    )


@act_bp.before_request
def check_user_verified():
    """
    Проверка статуса верификации пользователя перед каждым запросом.
    Если пользователь не верифицирован — сессия сбрасывается.
    """
    if current_user.is_authenticated and not current_user.is_verified:
        logout_user()
        session.clear()
        flash('Ваша сессия была сброшена администратором', 'warning')
        return redirect(url_for('auth.login'))
