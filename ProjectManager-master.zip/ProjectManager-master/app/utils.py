import os
import pythoncom
import pandas as pd
import psycopg2 as pc
from datetime import datetime
from win32com import client
from app.models import Employee
from app.app_logger import logger
from app import db

from .config import Settings

BACKUP_FOLDER = Settings.PATHS.get("excel_backup_dir", "app/backups")
BACKUP_FOLDER_QLIK = Settings.PATHS.get("qlik_backup_dir", "app/backups_qlik")
MAX_BACKUPS = Settings.BACKUP.get("max_backups", 5)

def format_period_column(df, column_name):
    def format_value(val):
        if pd.isna(val) or (isinstance(val, str) and not val.strip()):
            return val

        try:
            val_int = int(float(val))
        except Exception as e:
            return val
            
        val_str = str(val_int).strip()
        
        if val_str.isdigit() and len(val_str) >= 5:
            return f"{val_str[:4]}_{val_str[4:]}"
        return val

    df[column_name] = df[column_name].apply(format_value)

    return df

def create_excel_backup(app):
    """
    Создаёт резервную копию таблицы проектов в формате Excel в папке backups.
    Хранит не более MAX_BACKUPS последних файлов, удаляя самые старые.
    """
    from app.models import Project

    with app.app_context():
        os.makedirs(BACKUP_FOLDER, exist_ok=True)

        projects = Project.query.all()
        data = [p.to_dict() for p in projects]
        df = pd.DataFrame(data)

        df = format_period_column(df, 'ID проекта в рейтинге ТБ')

        filename = f'backup_{datetime.now().strftime("%Y-%m-%d")}.xlsx'
        path = os.path.join(BACKUP_FOLDER, filename)
        df.to_excel(path, index=False)

        files = sorted(
            [f for f in os.listdir(BACKUP_FOLDER) if f.endswith('.xlsx')],
            key=lambda x: os.path.getmtime(os.path.join(BACKUP_FOLDER, x))
        )

        while len(files) > MAX_BACKUPS:
            os.remove(os.path.join(BACKUP_FOLDER, files.pop(0)))

def create_excel_backup_qlik(app):
    """
    Создаёт резервную копию таблицы проектов в формате Excel в папке backups.
    Хранит не более MAX_BACKUPS последних файлов, удаляя самые старые.
    """
    from app.models import Project

    with app.app_context():
        os.makedirs(BACKUP_FOLDER_QLIK, exist_ok=True)

        files = sorted(
            [f for f in os.listdir(BACKUP_FOLDER_QLIK) if f.endswith('.xlsx')],
            key=lambda x: os.path.getmtime(os.path.join(BACKUP_FOLDER_QLIK, x))
        )

        if len(files) > 1:
            os.remove(os.path.join(BACKUP_FOLDER_QLIK, files.pop(0)))

        projects = Project.query.all()
        data = [p.to_dict_expt() for p in projects]
        df = pd.DataFrame(data)

        df = format_period_column(df, 'ID проекта в рейтинге ТБ')

        filename = f'AgBL_new.xlsx'
        path = os.path.join(BACKUP_FOLDER_QLIK, filename)
        df.to_excel(path, index=False)
            
def check_admin(user):
    """
    Проверяет, является ли пользователь администратором.
    Возвращает True, если user.status == 1, иначе False.
    """
    return user.status == 1

def send_internal_mail(recipient, body, subject='Код подтверждения'):
    """
    Отправляет письмо через Outlook (локальный клиент).
    Использует COM интерфейс Windows.

    :param recipient: email получателя
    :param body: текст письма
    :param subject: тема письма (по умолчанию 'Код подтверждения')
    """
    pythoncom.CoInitialize()
    try:
        outlook = client.Dispatch('Outlook.Application')
        mail = outlook.CreateItem(0)

        mail.SentOnBehalfOfName = Settings.OUTLOOK_SENDER
        mail.To = recipient
        mail.Subject = subject
        mail.Body = body
        mail.Send()
    finally:
        pythoncom.CoUninitialize()

def send_message_backup(file_path, recepient_email, subject='Автоматическая отправка файла для обновления Qlik'):
    import win32com.client

    pythoncom.CoInitialize()
    try:
        if not os.path.isfile(file_path):
            print(f'Файл {file_path} не найден')
            return False
    
        outlook = win32com.client.Dispatch('Outlook.Application')
        mail = outlook.CreateItem(0)
        mail.To = recepient_email
        mail.Subject = subject
        mail.Body = 'Последняя сводка проектов'

        mail.Attachments.Add(file_path)
        mail.Send()
        logger.info(f'Файл {os.path.basename(file_path)} отправлено на {recepient_email}')
        return True

    finally:
        pythoncom.CoUninitialize()

def create_excel_backlogs_sva(app):
    """
    Создает эксель-копию с проектами с потенциальным выходом на Backlog СВА
    """
    from app.models import Project
    
    filename = 'projects_Backlogs_SVA.xlsx'
    path = os.path.join(os.getcwd(), filename)

    with app.app_context():
        try:
            projects = Project.query.filter(
                Project.backlog_date.isnot(None)
            ).all()

            data = [p.to_dict_expt() for p in projects]
            df = pd.DataFrame(data)

            df = format_period_column(df, 'ID проекта в рейтинге ТБ')

            try:
                df.to_excel(path, index=False)
                send_message_backup(path, recepient_email=Settings.BACKUP_EMAIL_RECEPIENT, subject='Проекты с предполагаемой датой выхода на Backlog СВА')
            except Exception as e:
                logger.error(f'Ошибка записи проектов Backlog: {e}')

        except Exception as e:
            logger.error(f'Возникла ошибка отправки проектов с предполагаемым выходом на Backlog СВА: {e}')
        
def load_sva_persons(db):
    file = 'SVA_persons.xlsx'

    try:
        file_path = os.path.join(os.getcwd(), file)

        if not os.path.exists(file_path):
            logger.warning(f"Файл сотрудников не найден: {file_path}")
            return
        
        df = pd.read_excel(file_path)

        existing_staff_numbers = {
            str(row[0]).strip().zfill(8)
            for row in db.session.query(Employee.staff_number).all()
            if row[0] is not None
        }

        existing_emails = {
            str(row[0]).strip().lower()
            for row in db.session.query(Employee.email).all()
            if row[0] is not None and str(row[0]).strip()
        }

        added_count = 0
        skipped_count = 0

        for _, row in df.iterrows():
            staff_number = str(row["TAB_NUM"]).strip().zfill(8)
            email = str(row["EMAIL"]).strip().lower() if pd.notna(row["EMAIL"]) and str(row["EMAIL"]).strip() else None

            if staff_number in existing_staff_numbers:
                skipped_count += 1
                continue

            if email and email in existing_emails:
                skipped_count += 1
                continue

            emp = Employee(
                full_name=row["FIO"],
                staff_number=staff_number,
                position=row["JOB_TITLE"],
                department=row["DEPARTMENT"],
                email=email,
            )

            db.session.add(emp)
            existing_staff_numbers.add(staff_number)
            if email:
                existing_emails.add(email)

            added_count += 1

        db.session.commit()
        logger.info(f"Загрузка сотрудников завершена: добавлено {added_count}, пропущено {skipped_count}")

    except Exception as e:
        db.session.rollback()
        logger.error(f"[Ошибка загрузки сотрудников] {e}")

def get_gp_connection():

    filename = 'SVA_persons.xlsx'
    path = os.path.join(os.getcwd(), filename)

    try:
        gp = pc.connect(
                host=Settings.GP_HOST,
                database=Settings.GP_DATABASE,
                user=Settings.GP_USER,
                password=Settings.GP_PASSWORD,
                port=Settings.GP_PORT,
        )

        gp_cursor = gp.cursor()

        sql_query = """
            with tab_1 as (
                    select
                        full_name,
                        personnel_num,
                        inner_office_email 
                    from s_grnplm_ld_audit_da_sandbox_oapso.ex_tio_easup_person
                    where fire_date is null
                )
                select
                    fio,
                    staff_number,
                    email,
                    job_title,
                    department
                from (
                    select distinct
                        tab2.full_name as fio,
                        tab2.personnel_num as staff_number,
                        tab2.inner_office_email as email,
                        tab1.pos_full as job_title,
                        tab1.org_full as department,
                        tab1.actual_date,
                        tab1.date_start,
                        row_number() over (partition by tab1.i_pernr order by tab1.date_start desc) as rn
                    from prx_tio_easup_s_grnplm_as_audit_da_easup__20s.v_easup_smd_absence_21948936_view as tab1
                    join tab_1 as tab2
                    on tab2.personnel_num::int = tab1.i_pernr::int
                    where (lower(tab1.org_full) like '%отдел аудита%' or lower(tab1.org_full) = 'отдел планирования и развития')
                    and tab1.actual_date::date between (current_date - interval '7days') and current_date
                ) t
                where rn=1
    """

        gp_cursor.execute(sql_query)
        rows = gp_cursor.fetchall()
        columns = ['FIO', 'TAB_NUM', 'EMAIL', 'JOB_TITLE',	'DEPARTMENT']

        df = pd.DataFrame(rows, columns=columns)
        df.to_excel(path, index=False)

        gp_cursor.close()
        gp.close()
    
    except:
        print('GreenPlum connection error')
        print("USER:", repr(Settings.GP_USER))
        print("PASSWORD:", repr(Settings.GP_PASSWORD))


