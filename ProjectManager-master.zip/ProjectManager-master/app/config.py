from __future__ import annotations

import os
from pathlib import Path
from typing import Any

import yaml
from dotenv import load_dotenv

BASE_DIR = Path(__file__).resolve().parent.parent
ENV_FILE = BASE_DIR / ".env"
YAML_FILE = BASE_DIR / "config.yaml"

load_dotenv(ENV_FILE)

def load_yaml_config(path: Path= YAML_FILE) -> dict[str, Any]:
    if not path.exists():
        raise FileNotFoundError(f"Файл конфигурации не найден: {path}")

    with path.open("r", encoding="utf-8") as file:
        data = yaml.safe_load(file) or {}

    return data

yaml_config = load_yaml_config()

class Settings:
    SECRET_KEY: str = os.getenv("SECRET_KEY", "dev-secret-key")
    SQLALCHEMY_DATABASE_URI: str = os.getenv(
        "DATABASE_URL",
        "sqlite:///../instance/projects.db"
    )

    SQLALCHEMY_TRACK_MODIFICATIONS: bool = False

    SESSION_TYPE: str = os.getenv("SESSION_TYPE", "filesystem")
    SESSION_PERMANENT: bool = True
    SESSION_LIFETIME_DAYS: int = int(os.getenv("SESSION_LIFETIME_DAYS", "3"))
    SESSION_FILE_DIR: str = os.getenv("SESSION_FILE_DIR", "./flask_session")

    BACKUP_EMAIL_RECIPIENT: str = os.getenv("BACKUP_EMAIL_RECEPIENT", "")
    OUTLOOK_SENDER: str = os.getenv("OUTLOOK_SENDER", "")

    GP_HOST: str = os.getenv("GP_HOST", "")
    GP_DATABASE: str = os.getenv("GP_DATABASE", "")
    GP_USER: str = os.getenv("GP_USER", "")
    GP_PASSWORD: str = os.getenv("GP_PASSWORD", "")
    GP_PORT: int = int(os.getenv("GP_PORT", "5432"))

    PATHS: dict[str, Any] = yaml_config.get("paths", {})
    BACKUP: dict[str, Any] = yaml_config.get("backup", {})
    SCHEDULER: dict[str, Any] = yaml_config.get("scheduler", {})
    ANALYTICS: dict[str, Any] = yaml_config.get("analytics", {})
    
