from datetime import datetime, timedelta
from pathlib import Path
import os
import shutil

from flask import Flask
from flask_session import Session
from flask_wtf.csrf import CSRFProtect
from flask_babel import Babel
from flask_migrate import Migrate
from apscheduler.schedulers.background import BackgroundScheduler

from .config import Settings
from .extensions import db, login_manager
from .app_logger import logger
from app.models import Users, register_background_tasks
from datetime import datetime, timedelta
from app.forms import FeedBackHelpForm

from .utils import (
    create_excel_backup,
    create_excel_backup_qlik,
    send_message_backup,
    create_excel_backlogs_sva,
)

from app.routes.project_routes import notify_if_needed, every_week_notificate

# === ИНИЦИАЛИЗАЦИЯ РАСШИРЕНИЙ ===
csrf = CSRFProtect()
babel = Babel()
migrate = Migrate()
sess = Session()

scheduler = BackgroundScheduler()

def create_app() -> Flask:
    app = Flask(__name__)
    # === КОНФИГ ===
    app.config['SECRET_KEY'] = Settings.SECRET_KEY
    app.config['SQLALCHEMY_DATABASE_URI'] = Settings.SQLALCHEMY_DATABASE_URI
    app.config['SQLALCHEMY_TRACK_MODIFICATIONS'] = Settings.SQLALCHEMY_TRACK_MODIFICATIONS

    app.config['SESSION_TYPE'] = Settings.SESSION_TYPE
    app.config['SESSION_PERMANENT'] = Settings.SESSION_PERMANENT
    app.config['PERMANENT_SESSION_LIFETIME'] = timedelta(days=Settings.SESSION_LIFETIME_DAYS)
    app.config['SESSION_FILE_DIR'] = Settings.SESSION_FILE_DIR

    app.config['BABEL_DEFAULT_LOCATE'] = 'ru'

    # Создаем папку для сессий
    Path(app.config["SESSION_FILE_DIR"]).mkdir(parents=True, exist_ok=True)

    # === ИНИЦИАЛИЗАЦИЯ EXTENSIONS ===
    db.init_app(app)
    login_manager.init_app(app)
    csrf.init_app(app)
    migrate.init_app(app, db)
    sess.init_app(app)

    # === LOGIN MANAGER ===
    login_manager.login_view = 'auth.login'  # Редирект при попытке доступа к защищенным страницам без авторизации
    login_manager.login_message = "Пожалуйста, войдите в систему"
    login_manager.login_message_category = "warning"

    # Регистрируем фоновые задачи, если есть
    register_background_tasks(app)

    @login_manager.user_loader
    def load_user(user_id):
        """Загружает пользователя по ID для Flask-Login."""
        return Users.query.get(int(user_id))

    
    def get_locale():
        return "ru"

    babel.init_app(app, locale_selector=get_locale)

    def fio_to_initials(value):
        """
        Фильтр Jinja2 для преобразования ФИО в формат 'Фамилия И.О.'.
        Пример: Иванов Иван Иванович -> Иванов И.И.
        """
        import re
        pattern = r'^(\S+)\s+(\S)\S*\s+(\S)\S*$'
        return re.sub(pattern, r'\1 \2.\3.', value)

    app.jinja_env.filters['fio_to_initials'] = fio_to_initials

    @app.context_processor
    def inject_report_form():
        return {'report_form':FeedBackHelpForm()}

    from .routes.auth_routes import auth_bp
    from .routes.project_routes import project_bp
    from .routes.admin_routes import admin_bp
    from .routes.actions_routes import act_bp
    from .routes.analytics_routes import analytics_bp

    app.register_blueprint(auth_bp)
    app.register_blueprint(project_bp)
    app.register_blueprint(admin_bp)
    app.register_blueprint(act_bp)
    app.register_blueprint(analytics_bp)

    with app.app_context():
        db.create_all()
        register_background_tasks(app)

    configure_scheduler(app)

    return app


def configure_scheduler(app: Flask) -> None:
    if scheduler.running:
        return

    scheduler_cfg = Settings.SCHEDULER
    file_to_send = str(Path(Settings.PATHS.get("qlik_export_file", "app/backups_qlik/AgBL_new.xlsx")).resolve())
    recipient = Settings.BACKUP_EMAIL_RECIPIENT

    def backup_database():
        with app.app_context():
            try:
                db_path = Path(app.root_path).parent / "instance" / "projects.db"
                db_backup_dir = Path('\\\\parma1051.omega.sbrf.ru\\VOL2_FolderRedirection\\LZO-VARM\\21948936_OMEGA\\DESKTOP\\backups_db')
                db_backup_dir.mkdir(parents=True, exist_ok=True)

                if not db_path.exists():
                    logger.warning(f"Файл БД не найден: {db_path}")
                    return

                timestamp = datetime.now().strftime("%Y-%m-%d_%H-%M-%S")
                backup_path = db_backup_dir / f"project_backup_{timestamp}.db"

                shutil.copy(db_path, backup_path)
                logger.info(f"Backup БД создан: {backup_path}")

            except Exception as e:
                logger.exception(f"Ошибка backup БД: {e}")

    def send_backup_message_job():
        with app.app_context():
            try:
                if not recipient:
                    logger.warning("Не задан BACKUP_EMAIL_RECIPIENT")
                    return

                if not Path(file_to_send).exists():
                    logger.warning(f"Файл не найден: {file_to_send}")
                    return

                send_message_backup(file_to_send, recipient)
                logger.info("Резервная копия Excel отправлена на почту")

            except Exception as e:
                logger.exception(f"Ошибка отправки backup: {e}")

    def backup_excel_job():
        with app.app_context():
            try:
                create_excel_backup(app)
                logger.info("Backup Excel выполнен")
            except Exception as e:
                logger.exception(f"Ошибка backup Excel: {e}")

    def backup_qlik_job():
        with app.app_context():
            try:
                create_excel_backup_qlik(app)
                logger.info("Backup Qlik выполнен")
            except Exception as e:
                logger.exception(f"Ошибка backup Qlik: {e}")

    def check_expired_projects_job():
        with app.app_context():
            try:
                notify_if_needed()
            except Exception as e:
                logger.exception(f"Ошибка проверки проектов: {e}")

    def send_notify_job():
        with app.app_context():
            try:
                every_week_notificate()
            except Exception as e:
                logger.exception(f"Ошибка уведомлений: {e}")

    def backlogs_sva_job():
        with app.app_context():
            try:
                create_excel_backlogs_sva(app)
                logger.info("Обновление backlog SVA выполнено")
            except Exception as e:
                logger.exception(f"Ошибка backlog SVA: {e}")    

    # --- Бэкап Excel ---
    scheduler.add_job(
        backup_excel_job,
        "interval",
        hours=scheduler_cfg.get("backup_excel_hours", 24),
        id="backup_excel_job",
        replace_existing=True,
        misfire_grace_time=300,
        max_instances=1,
        coalesce=True,
    )

    # --- Бэкап Qlik ---
    scheduler.add_job(
        backup_qlik_job,
        "interval",
        hours=scheduler_cfg.get("backup_qlik_hours", 24),
        id="backup_qlik_job",
        replace_existing=True,
        misfire_grace_time=300,
        max_instances=1,
        coalesce=True,
    )

    # --- Отправка письма ---
    scheduler.add_job(
        send_backup_message_job,
        "interval",
        hours=scheduler_cfg.get("send_backup_message_hours", 24),
        id="send_backup_message_job",
        replace_existing=True,
        misfire_grace_time=300,
        max_instances=1,
        coalesce=True,
    )

            
    # --- Создание бекапа БД ---
    scheduler.add_job(
        backup_database,
        "interval",
        hours=scheduler_cfg.get("backup_database_hours", 24),
        id="backup_database_job",
        replace_existing=True,
        misfire_grace_time=300,
        max_instances=1,
        coalesce=True,
    )

    # --- Проверка просроченных проектов ---
    scheduler.add_job(
        check_expired_projects_job,
        "interval",
        hours=scheduler_cfg.get("check_expired_projects_hours", 12),
        id="check_expired_projects_job",
        replace_existing=True,
        misfire_grace_time=300,
        max_instances=1,
        coalesce=True,
    )

    # --- Отправка сообщений напоминаний ---
    scheduler.add_job(
        send_notify_job,
        "interval",
        hours=scheduler_cfg.get("send_notify_hours", 120),
        id="send_notify_job",
        replace_existing=True,
        misfire_grace_time=300,
        max_instances=1,
        coalesce=True,
    )       

    # --- Отправка проектов с потенциальным выходом на Backlog СВА ---
    scheduler.add_job(
        backlogs_sva_job,
        "interval",
        hours=scheduler_cfg.get("backlogs_sva_hours", 172),
        id="backlogs_sva_job",
        replace_existing=True,
        misfire_grace_time=300,
        max_instances=1,
        coalesce=True,
    )     

    scheduler.start()
    logger.info("Scheduler запущен")
